import Pusher from 'pusher-js'
let token = '6237f13abbb00257cb49'

if (process.env.NODE_ENV === 'production') {
  token = 'e28dbc5a6cd2df9304cc'
}

const pusher = new Pusher(token, {
  cluster: 'us2'
})

export default pusher
