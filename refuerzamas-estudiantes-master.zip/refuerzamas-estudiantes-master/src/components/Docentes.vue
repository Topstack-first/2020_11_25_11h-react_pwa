<template>
  <div class="Docentes">
    <v-sheet
      class="mx-auto vertical w-100"
      max-width="800"
    >
      <v-slide-group
        v-model="model2"
        class="pa-4 pt-0 pr-0"
        active-class=""
        show-arrows
      >
        <v-slide-item
          v-for="docente in docentes"
          :key="docente.id"
          v-slot:default="{ toggle }"
        >

          <!-- Contenedor -->
          <div
            class="ma-4 card-profesores horizontal w-100"
            @click="toggle"
          >
            <v-row class="card-profesores rounded-lg ml-1 border">
              <!--Primera Columna -->
              <v-col cols="4" class="text-center d-flex flex-column justify-center align-center">
                <!-- Img Avatar Docentes -->
                <v-avatar class="avatar-docentes">
                  <img :src="docente.avatar || userDefaultAvatar" :alt="docente.display_name">
                </v-avatar>
                <!-- Fin Avatar Docentes -->
                <!--Valoracion Docentes -->
                <v-btn
                  class="color-empresa text-transform rounded-pill mt-2"
                  color="white"
                  dark
                  elevation="2"
                  x-small
                >
                  {{ docente.perfil_docente.estrellas }}<img src="@/assets/img/icon/start.svg" alt="Icon | Refuerza +">
                </v-btn>
                <!-- Fin Valoracion Docentes -->
              </v-col>
              <!-- Fin Primera Columna -->

              <!-- Segunda Columna -->
              <v-col cols="8" class="text-center d-flex flex-column justify-space-between align-center">
                <!-- Nombre Docentes-->
                <p class="my-0 color-empresa col-docente-nom-docente">Prof. {{ docente.display_name }}</p>
                <!-- Fin Nombre Docentes-->
                <!-- btn ver perfil-->
                <p class="my-1 titulo-promocion color-empresa" style="font-size: 12px;white-space:break-spaces">{{ getMaterias(docente.perfil_docente.materias) }}</p>
                <v-btn
                  :to="{name: 'Perfil_docente', params:{id: docente.id}}"
                  class="my-0 color-empresa text-transform rounded-pill white--text background-clases"
                  dark
                  x-small
                  style="letter-space:normal"
                >
                  Ver perfil
                </v-btn>
                <!-- Fin btn perfil -->
              </v-col>
              <!-- Fin Segunda Columna -->
            </v-row>
          </div>
          <!-- Fin Contenedor -->

        </v-slide-item>
      </v-slide-group>
    </v-sheet>
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import userDefaultAvatar from '@/assets/img/user_default.jpg'

export default {
  data () {
    return {
      model2: null,
      userDefaultAvatar
    }
  },
  computed: {
    ...mapState(['docentes'])
  },
  methods: {
    ...mapActions(['fetchDocentes']),
    getMaterias (materias) {
      return materias.map(materia => {
        return materia.nombre
      }).join(',')
    }
  },
  mounted () {
    this.fetchDocentes()
  }
}
</script>

<style scoped>
.avatar-docentes {
  height: 35px !important;
  width: 35px !important;
}

.col-docente-nom-docente {
  font-weight: 600;
  font-size: 13px;
  white-space: break-spaces;
}

.card-profesores {
    max-width: 285px;
}
@media (min-width: 850px) {
  .vertical {
    writing-mode: vertical-lr !important;
    height: auto;
  }

  .horizontal {
    writing-mode: horizontal-tb;
    width: 100%;
    height: 100%;
  }

  .card-profesores {
    width: 255px;
  }
}
</style>
