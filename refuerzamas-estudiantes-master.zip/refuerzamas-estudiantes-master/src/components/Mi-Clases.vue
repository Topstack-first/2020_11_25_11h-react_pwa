<template>
  <div class="mi-clases">
    <v-sheet
      class="mx-auto vertical"
      max-width="800"
    >
      <v-slide-group
        v-model="model"
        class="pa-4 pt-0 pr-0"
        active-class=""
        show-arrows
      >
        <v-slide-item
          v-for="clase in clases"
          :key="clase.id"
          v-slot:default="{ active, toggle }"
        >

          <!-- Contenedor -->
          <div
            :color="active ? undefined : 'white'"
            class="ma-4 rounded-lg card-clases"
            flat
            @click="toggle"
          >
            <v-row class="row-clases rounded-lg horizontal">
              <!-- Primera Columna -->
              <v-col cols="4" class="py-0 px-0 h-100">
                <div class="fondo-clases rounded-l-lg">
                  <div class="d-flex justify-end w-100">
                    <!-- Avatar Docentes -->
                    <v-avatar class="mt-14 mr-n6 avatar-clases">
                      <img :src="clase.docente.avatar || userDefaultAvatar" alt="John">
                    </v-avatar>
                    <!-- Avatar Docentes -->
                  </div>
                  <div class="d-flex justify-end">
                    <!-- Valoración Docentes -->
                    <v-btn
                      class="mr-n5 mt-3 pt-1 pb-1 color-empresa text-transform rounded-pill btn-valoracion"
                      color="white"
                      dark
                      x-small
                    >
                      <span>{{ clase.docente.perfil_docente.estrellas }}</span> <img src="@/assets/img/icon/start.svg"
                                                                                     alt="Icon | Refuerza +">
                    </v-btn>
                    <!-- Valoración Docentes -->
                  </div>
                  <center>
                    <!-- Btn Activo -->
                    <v-btn
                      class="ma-2 color-empresa text-transform rounded-pill btn-activo"
                      color="white"
                      elevation="0"
                      dark
                      x-small
                    >
                      <img src="@/assets/img/icon/check.svg" alt="Icon | Refuerza +">
                      {{ clase.estado }}
                    </v-btn>
                    <!-- Btn Activo -->
                  </center>
                </div>
              </v-col>
              <!-- Fin Primera Columna -->

              <!-- Segunda Columna -->
              <v-col cols="8" class="pl-8 pl2-clases">
                <div class="d-flex justify-space-between">
                  <div class="pt-2" style="width:80%">
                    <!-- Nombre de la Clase -->
                    <p class="titulo-curso-clases">{{ clase.curso.materia.nombre }}</p>
                    <!-- Fin Nombre de la Clase -->
                  </div>
                  <div class="ml-2">
                    <v-menu
                      left
                      offset-y
                    >
                      <template v-slot:activator="{ on, attrs }">
                        <v-btn
                          color="white"
                          text
                          v-bind="attrs"
                          v-on="on"
                        >
                          <img class="mr-n7" src="@/assets/img/icon/puntitos.svg" alt="Icon | Refuerza +">
                        </v-btn>
                      </template>

                      <v-list class="mb-0 pb-0">
                        <v-list-item
                          style="border-bottom:1px solid #E5E5E5"
                          v-for="(item, index) in items"
                          :key="index"
                          :href="item.url"
                          target="_blank"
                        >
                          <v-list-item-title class="color-empresa"
                                             style="font-weight: 600;font-size: calc(12px + 2px);line-height: 17px;">
                            {{ item.title }}
                          </v-list-item-title>
                        </v-list-item>
                      </v-list>
                    </v-menu>
                    <!-- Icono -->

                    <!-- Fin Icono -->
                  </div>
                </div>
                <!-- Nombre Docente-->
                <p class="profe-clases w-100 mb-1">{{ clase.user.short_display_name || clase.user.display_name }}</p>
                <!-- Fin Nombre Docente-->

                <!-- Horario -->
                <p class="horario-clases">{{ calcularDia(clase.hora_inicio) }}, de
                  {{ clase.hora_inicio | moment('hh:mma') }} a {{ clase.hora_fin | moment('hh:mma') }}</p>
                <template v-if="user" class="mb-0">
                  <p v-if="user.tipo_usuario === 'TUTOR'" class="d-flex align-center tutor-margin"
                     style="color: #311FB5;font-weight: 500;font-size: 0.9rem;">
                    <v-img class="flex-grow-0 mr-1" style="border-radius: 50%;" height="25" width="25"
                           :src="clase.user.avatar || userDefaultAvatar"></v-img>
                    {{ clase.user.display_name.split(' ')[0] }}
                  </p>
                </template>
                <!-- Fin Horario -->
                <center>
                  <!-- Btn Detalles -->
                  <v-btn
                    :to="{name: 'Clase', params: {id: clase.id}}"
                    class="ma-2 mt-0 ml-0 w-100 color-empresa white--text text-transform rounded-pill btn-detalles"
                    dark
                  >
                    Ver detalles
                  </v-btn>
                  <!-- fin btn detalles -->
                </center>
              </v-col>
              <!--Fin segunda Columna -->
            </v-row>
          </div>
          <!-- Fin Contenedor -->

        </v-slide-item>
      </v-slide-group>
    </v-sheet>
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import userDefaultAvatar from '@/assets/img/user_default.jpg'
import moment from 'moment'

export default {
  data () {
    return {
      model: null,
      userDefaultAvatar,
      items: [
        {
          url: 'https://wa.link/77gk85',
          title: 'Reportar'
        },
        {
          url: 'https://wa.link/mzh3ts',
          title: 'Reprogramar'
        },
        {
          url: 'https://wa.link/nqu8cn',
          title: 'Cancelar'
        }
      ]
    }
  },
  computed: {
    ...mapState(['clases']),
    ...mapState('perfil', ['user'])
  },
  methods: {
    ...mapActions(['fetchClases']),
    ...mapActions('perfil', ['fetchUser']),
    calcularDia (fecha) {
      return moment(fecha).calendar({
        sameDay: '[Hoy]',
        nextDay: '[Mañana]',
        nextWeek: 'dddd',
        lastDay: '[Ayer]',
        lastWeek: 'dddd [pasado]',
        sameElse: '[El] DD [de] MMM [del] YYYY'
      })
    }
  },
  mounted () {
    this.fetchUser()
    this.fetchClases()
  }
}
</script>

<style scoped src="@/assets/css/Estilos-Inicio.css"></style>
