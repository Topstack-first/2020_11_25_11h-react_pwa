<template>
  <div class="cabecera">
    <!-- Cabecera --->
    <v-app-bar
      color="white"
    >
      <!-- Icono de Menú -->
      <v-btn @click.stop="drawer = !drawer" :to="to" elevation="0" x-small width="43" height="43" class="rounded-circle" color="transparent">
        <div class="cursor rounded-circle">
          <img class="my-2 mx-2" :src="Icono" alt="Icono menú | Refuerza +">
        </div>
      </v-btn>

      <!-- Fin Icono de Menú -->

      <v-spacer></v-spacer>

      <!-- Logo -->
      <img class="logo" width="45%" src="@/assets/img/logo.svg" alt="Logo | Refuerza +">
      <!-- Fin Logo -->

      <v-spacer></v-spacer>

      <!--Icon -->
      <img class="mr-2 d-none-x" src="@/assets/img/icon/stats.svg" alt="Icon | Refuerza +">
      <!--Icon -->

      <!--Nombre user -->
        <span class="nombre-user d-none-x">{{ user.display_name }}</span>
      <!--Fin Nombre User -->

      <!-- Avatar User -->
      <v-btn text :to="{name: 'Perfil'}" width="10" height="0" class="rounded-circle">
        <v-avatar class="avatar-user ml-2 d-none-x">
          <img :src="user.avatar || userDefaultAvatar" alt="John">
        </v-avatar>
      </v-btn>
      <!-- Fin Avatar User -->

      <!-- Icono messenger -->
      <v-btn :to="{name: 'Mensajes'}" elevation="0" x-small width="43" height="43" class="rounded-circle" color="transparent">
        <div class="cursor rounded-circle">
          <img class="my-2 mx-2" src="@/assets/img/icon/messenger.svg" alt="Icono messenger | Refuerza +">
        </div>
      </v-btn>
      <!-- Fin Icono messenger -->
    </v-app-bar>
    <!-- Fin Cabecera -->

    <v-navigation-drawer
        v-model="drawer"
        absolute
        temporary
        :class="'rounded-r-xl'"
      >
        <v-list
          nav
          dense
        >
          <v-list-item-group
            v-model="group"
          >
            <v-container class="mt-2">
              <p>Hola</p>
              <h3>{{ user.display_name}}</h3>
            </v-container>
            <v-divider></v-divider>
            <v-container class="">
              <v-list-item :to="{name: 'Perfil'}">
                <v-list-item-title class="mb-5 font-size-1 font-weight-normal"><v-list-item-avatar height="25px" style="border-radius:inherit!important"><img src="@/assets/img/icon/user.svg"></v-list-item-avatar>Datos de Perfil</v-list-item-title>
              </v-list-item>
              <v-list-item :to="{name: 'Mensajes'}">
                <v-list-item-title class="mb-5 font-size-1 font-weight-normal"><v-list-item-avatar height="25px" style="border-radius:inherit!important"><img src="@/assets/img/icon/messenger.svg"></v-list-item-avatar>Mensajes</v-list-item-title>
              </v-list-item>
<!--              <v-list-item>-->
<!--                <v-list-item-title class="mb-5 font-size-1 font-weight-normal"><v-list-item-avatar height="25px" style="border-radius:inherit!important"><img src="@/assets/img/icon/config.svg"></v-list-item-avatar>Configuraciones</v-list-item-title>-->
<!--              </v-list-item>-->
              <v-list-item @click="doLogout()">
                <v-list-item-title class="font-size-1 font-weight-normal"><v-list-item-avatar height="25px" style="border-radius:inherit!important"><img src="@/assets/img/icon/exit.svg"></v-list-item-avatar>Cerrar Sesión</v-list-item-title>
              </v-list-item>
            </v-container>

          </v-list-item-group>
          <v-container bottom class="d-flex justify-center" style="">
            <img src="" alt="">
          </v-container>
        </v-list>
      </v-navigation-drawer>
  </div>
</template>

<script>
import userDefaultAvatar from '@/assets/img/user_default.jpg'
import { mapActions, mapState } from 'vuex'

export default {
  props: {
    Icono: String,
    to: String
  },
  data () {
    return {
      userDefaultAvatar,
      drawer: false,
      group: null
    }
  },
  computed: {
    ...mapState('perfil', ['user'])
  },
  methods: {
    ...mapActions('perfil', ['fetchUser']),
    ...mapActions(['logout']),
    doLogout () {
      this.logout()
      this.$router.push({ name: 'Login' })
    }
  },
  async mounted () {
    await this.fetchUser()
  }
}
</script>
<style>

  .nombre-user{
    font-weight: 600;
    font-size: 15px;
    line-height: 17px;
    color:#3F3A64;
    white-space: break-spaces;
  }

  .avatar-user{
    height:35px!important;
    width:35px!important;
  }

  .logo{
    justify-content: center;
    margin-left: 50px;
  }
  @media (min-width: 850px){
    .cabecera .logo{
      height: 25px!important;
      margin-left: 10%;
    }
    .d-none-x{
      display:initial!important;
    }
  }
</style>
