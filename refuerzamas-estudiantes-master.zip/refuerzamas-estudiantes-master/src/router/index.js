import Vue from 'vue'
import VueRouter from 'vue-router'
import Inicio from '../views/Inicio.vue'
import { ifAuthenticated, ifNotAuthenticated } from '@/utils/router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/inicio',
    name: 'Inicio',
    beforeEnter: ifAuthenticated,
    component: Inicio
  },
  {
    path: '/login',
    name: 'Login',
    beforeEnter: ifNotAuthenticated,
    component: () => import(/* webpackChunkName: "Login" */ '../views/Login.vue')
  },
  {
    path: '/perfil',
    name: 'Perfil',
    beforeEnter: ifAuthenticated,
    component: () => import(/* webpackChunkName: "Perfil" */ '../views/Perfil.vue')
  },
  {
    path: '/clases/:id',
    name: 'Clase',
    beforeEnter: ifAuthenticated,
    component: () => import(/* webpackChunkName: "ver detalles" */ '../views/Ver_detalles.vue')
  },
  {
    path: '/docente/:id',
    name: 'Perfil_docente',
    beforeEnter: ifAuthenticated,
    component: () => import(/* webpackChunkName: "Perfil Docente" */ '../views/Perfil_docente.vue')
  },
  {
    path: '/mensajes',
    name: 'Mensajes',
    beforeEnter: ifAuthenticated,
    component: () => import(/* webpackChunkName: "Mensajes" */ '../views/Mensajes.vue')
  },
  // {
  //   path: '/inbox',
  //   name: 'Inbox',
  //   component: () => import(/* webpackChunkName: "Inbox" */ '../views/Inbox.vue')
  // },
  {
    path: '*',
    redirect: { name: 'Inicio' }
  }
  // {
  //   path: '/ver_detalles',
  //   name: 'Ver_detalles',
  //   component: () => import(/* webpackChunkName: "ver detalles" */ '../views/Ver_detalles.vue')
  // }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
