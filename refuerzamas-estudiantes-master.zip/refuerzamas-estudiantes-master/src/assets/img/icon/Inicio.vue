<template>
  <v-container class="responsive-div div-responsive px-0 py-0">
     <v-img class="mb-8" src="@/assets/fondos/inicio.svg" max-height="">
        <v-row style="align-content:" class="lightbox white--text pa-2 fill-height">
          <v-col cols="6" style="height:70px">
            <v-app-bar-nav-icon class=" ml-5" color="white" @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
          </v-col>
          <v-col :class="'mr-2'" align="end" cols="5" style="height:70px">
            <img src="@/assets/logos/logo-inicio.svg" alt="">
          </v-col>
          <v-col align="" cols="12" class="ml-5">            
              <img class="white rounded-circle border-solid-4" src="@/assets/img/foto-prueba.svg" alt="" style="height:53px;width:53px;">
            <p class="ml-1 font-weight-6 font-size-1-2"><span>Dr. Jeremy Soto</span></p>
          </v-col>
          <v-row style="justify-content:center">
            <div class="rounded-lg white box-shadow-0-7" style="width:80%;" >
              <v-row>
                <v-col class="mb-0 pb-0 mt-2" >
                  <v-row >
                    <v-col class="d-flex justify-center mb-0 pb-0" cols="12">
                      <h2 class="black--text">305</h2>
                    </v-col>
                    <v-col class="mt-0 pt-0 mb-0 pb-0 d-flex justify-center" cols="12">
                      <img src="@/assets/img/rectangulo.svg" alt="">
                    </v-col>
                  </v-row>
                </v-col>
                <v-col class="pt-0 mb-0 pb-0">
                  <v-row>
                    <v-col class="pt-0 d-flex justify-end" cols="12">
                      <div class="blue rounded-tr-lg height-2">
                        <p class="ml-4 mr-3 mt-2 mb-2 white--text font-size-0-6"><span>SEPTIEMBRE</span></p>
                      </div>
                    </v-col>
                    <v-col class="d-flex justify-center pt-0 mb-0 pb-0">
                      <v-row>
                        <v-col cols="12" class="mb-0 pb-0 height-3">
                          <p class="black--text font-size-1-5 font-weight-6 text-align-center">Tu puesto</p><br>
                        </v-col>
                        <v-col class="mt-0 pt-0 mb-0 pb-0">
                          <p class="grey--text font-size-0-6 mb-0 pb-0 text-align-center" >Entre 1,354 usuarios</p>
                        </v-col>
                      </v-row>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
            </div>
          </v-row>
        </v-row>       
      </v-img>

      <v-navigation-drawer
        v-model="drawer"
        absolute
        temporary
        :class="'rounded-r-xl'"
      >
        <v-list
          nav
          dense
        >
          <v-list-item-group
            v-model="group"
          >
            <v-container class="mt-2">
              <p>Hola</p>
              <h3>Dr. Jeremy Soto</h3>
            </v-container>
            <v-container class="">
              <v-card width="100%" height="120px"></v-card>
            </v-container>
            <v-container class="">
              <v-list-item>
                <v-list-item-title class="mb-5 font-size-1 font-weight-normal"><v-list-item-avatar height="25px" style="border-radius:inherit!important"><img src="@/assets/icon/user.svg"></v-list-item-avatar>Datos de Perfil</v-list-item-title>
              </v-list-item>
              <v-list-item>
                <v-list-item-title class="mb-5 font-size-1 font-weight-normal"><v-list-item-avatar height="25px" style="border-radius:inherit!important"><img src="@/assets/icon/tarjeta.svg"></v-list-item-avatar>Métodos de pagos</v-list-item-title>
              </v-list-item>
              <v-list-item>
                <v-list-item-title class="mb-5 font-size-1 font-weight-normal"><v-list-item-avatar height="25px" style="border-radius:inherit!important"><img src="@/assets/icon/config.svg"></v-list-item-avatar>Configuraciones</v-list-item-title>
              </v-list-item>
              <v-list-item>
                <v-list-item-title class="font-size-1 font-weight-normal"><v-list-item-avatar height="25px" style="border-radius:inherit!important"><img src="@/assets/icon/exit.svg"></v-list-item-avatar>Cerrar Sesión</v-list-item-title>
              </v-list-item>
            </v-container>
            
          </v-list-item-group>
          <v-container bottom class="d-flex justify-center" style="">
            <img src="@/assets/img/medicos.svg" alt="">
          </v-container>
        </v-list>
      </v-navigation-drawer>

      <v-sheet
      class="mx-auto carousel-btn mt-0 pt-0"
      elevation="8"
      max-width="800"
      >
        <v-slide-group
          v-model="model"
          class="pa-4 carousel-cd"
          center-active
          show-arrows
        >
          <v-slide-item
            v-for="item in items2"
            :key="item.aa"
            v-slot:default="{ toggle }"
          >
            <v-card 
              class="ma-4 ml-5 mr-1 mt-0 pt-0 btn_color_degrado"
              height="100"
              width="300"
              @click="toggle"
            >
              <div class="d-flex justify-end mt-5">
                <div class="mr-5" style="width:60%"> 
                  <span class="white--text" style="font-size:1.2rem;font-weight:600">{{item.titulo}}</span><br>
                  <span class="white--text" style="font-size:0.75rem;font-weight:200">{{item.texto}}</span>
                </div>
                <div class="">
                  <img src="@/assets/icon/play.svg" alt="">
                </div>
              </div>
            </v-card>            
          </v-slide-item>
        </v-slide-group>
      </v-sheet>



    

  <v-container class="pl-5 pr-5">
    <v-list two-line >
      <v-subheader class="font-weight-5 black--text pl-2">Examenes Recientes</v-subheader>

      <v-list-item
        v-for="item in items"
        :key="item.title" 
      >
        <v-list-item-avatar class="border-radius-inherit">
          <v-img :src="item.avatar2"></v-img>
        </v-list-item-avatar>

        <v-list-item-content>
          <v-list-item-title class="black--text font-weight-5" v-text="item.title"></v-list-item-title>
          <v-list-item-subtitle class="grey-text font-size-0-8" v-text="item.subtitle"></v-list-item-subtitle>
        </v-list-item-content>

        <v-list-item-avatar class="border-radius-inherit rounded-lg " style="width:20%!important">
          <v-btn :class="item.estado" class="btn white--text  box-shadow-none font-size-8" style="width:100%"  v-text="item.note"></v-btn>
        </v-list-item-avatar>
      </v-list-item>
    </v-list>
  </v-container>

<v-container style="height:80px">

</v-container>



    <v-footer
      :padless="true"
      fixed  
      class="box-shadow"
    >
      <v-card
        flat
        tile
        width="100%"
        class="white lighten-1 text-center"
      >
        <v-card-text>
          <v-btn           
            class="mx-4"
            icon
          >
            <img size="24px" src="@/assets/icon/menu-barra.svg" alt="">
            <img class="ml-15 mr-15" size="24px" src="@/assets/icon/menu-home.svg" alt="">
            <img size="24px" src="@/assets/icon/menu-car.svg" alt="">
          </v-btn>
        </v-card-text>        
      </v-card>
    </v-footer>

  </v-container>
</template>

<script>

  export default {
    data () {       
      return {
      model: null,  
      drawer: false,
      group: null,
      show1: false,
      password: '',
      email: '',
      rules: {
        required: value => !!value || 'Required.',
        min: v => v.length >= 8 || 'Min 8 caracteres',
        email: value => {
          const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
          return pattern.test(value) || 'Correo invalido.'
        },
      },
       icons: [
        'mdi-home',
        'mdi-calendar',
        
      ],
      padless: false,
      variant: 'fixed',
      items: [
        { avatar2: 'https://www.chioscoffebreak.com/img/virus.svg', title: 'COVID 2020 I',subtitle: '1 de Septiembre', note: '15/35', estado:'amber darken-1' },
        { avatar2: 'https://www.chioscoffebreak.com/img/bisturi.svg',title: 'CIRUGÍA 2020',subtitle: '2 de Septiembre', note: '15/35',estado:'red lighten-1'  },
        { avatar2: 'https://www.chioscoffebreak.com/img/virus.svg', title: 'COVID 2020 II',subtitle: '1 de Septiembre', note: '15/35', estado:'amber darken-1' },
        { avatar2: 'https://www.chioscoffebreak.com/img/bisturi.svg',title: 'CIRUGÍA 2020 II',subtitle: '2 de Septiembre', note: '15/35' ,estado:'red lighten-1' },
      ],
      items2: [
        {titulo:'Banqueo',texto:'Examenes para medir tu progreso'},
        {titulo:'Simulacro',texto:'Maratón de preguntas'}
      ],
      }
    },
    watch: {
      group () {
        this.drawer = false
      },
    },
  }
</script>


<style>
  .btn-nav{margin-top:-170%;}.box-shadow-0-7{box-shadow: 0px 4px 16px rgba(0, 0, 0, 0.07);}.border-solid-4{border:4px solid}.carousel-btn .v-slide-group__next, .carousel-btn .v-slide-group__prev{display: none;}.carousel-btn{width: 100%; display: contents; justify-content: flex-end;}.carousel-cd{display: contents;}
</style>
