import axios from 'axios'

export default {
  fetchChats: async ({ commit }) => {
    const chatsResponse = await axios.get('api/chats/')
    const chats = chatsResponse.data
    commit('SET_CHATS', chats)
  },
  async marcarComoVisto ({ commit }, payload) {
    const chatResponse = await axios.post(`/api/chats/${payload}/revisado/`)
    const chats = chatResponse.data
    commit('SET_CHATS', chats)
  }
}
