import { set } from '@/utils/vuex'

export default {
  SET_CHATS: set('chats')
}
