export default {
  chats: []
}
