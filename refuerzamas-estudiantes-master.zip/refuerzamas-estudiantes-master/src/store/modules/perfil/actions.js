import axios from 'axios'

export default {
  fetchUser: async ({ commit }) => {
    const userResponse = await axios.get('/api/auth/user/')
    const user = userResponse.data
    commit('SET_USER', user)
  },
  updateUser: async ({ commit }, payload) => {
    const userResponse = await axios.patch('/api/auth/user/', payload)
    const user = userResponse.data
    commit('SET_USER', user)
  },
  updatePhoto: async ({ commit }, payload) => {
    const userResponse = await axios.patch('api/auth/user/', payload)
    const user = userResponse.data
    commit('SET_USER', user)
  },
  fetchInstituciones: async ({ commit }, payload) => {
    const institucionesResponse = await axios.get('api/instituciones/')
    const instituciones = institucionesResponse.data
    commit('SET_INSTITUCIONES', instituciones)
  },
  fetchGeneros: async ({ commit }, payload) => {
    const generosResponse = await axios.get('api/generos/')
    const generos = generosResponse.data
    commit('SET_GENEROS', generos)
  },
  fetchNiveles: async ({ commit }, payload) => {
    const nivelesResponse = await axios.get('api/niveles/')
    const niveles = nivelesResponse.data
    commit('SET_NIVELES', niveles)
  },
  fetchGradosByNivel: async ({ commit }, payload) => {
    let grados = []
    if (payload) {
      const gradosResponse = await axios.get(`api/niveles/${payload}/grados/`)
      grados = gradosResponse.data
    }
    commit('SET_GRADOS', grados)
  }
}
