import { set } from '@/utils/vuex'

export default {
  SET_USER: set('user'),
  SET_INSTITUCIONES: set('instituciones'),
  SET_GENEROS: set('generos'),
  SET_NIVELES: set('niveles'),
  SET_GRADOS: set('grados')
}
