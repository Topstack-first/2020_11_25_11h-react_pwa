export default {
  user: {
    id: '',
    username: null,
    nickname: null,
    tipo_usuario: null,
    avatar: null,
    fecha_nacimiento: null,
    celular: null,
    email: null,
    direccion: null,
    observaciones: null,
    genero_id: null,
    perfil_estudiante: {
      institucion_id: null,
      grado_id: null,
      tutor: {
        nickname: null,
        avatar: null,
        celular: null,
        direccion: null,
        observaciones: null
      }
    }
  },
  instituciones: [],
  generos: [],
  niveles: [],
  grados: []
}
