<template>
  <div class="Inicio">
    <!--Cabecera -->
    <Cabecera :Icono="IconoMenu"/>
    <!-- Fin Cabecera -->

    <!-- Cuerpo -->
    <div id="cuerpo" class="cuerpo-inicio">
      <v-row class="mr-0">
        <!-- Columna Mis Clases -->
        <v-col cols="12" md="5" sm="12" class="order-sm-3 order-md-2 pr-0 pb-0">

          <!--Titulo Mis Clases | Hoy-->
          <div class="d-flex justify-space-between mt-5 pl-4 ml-4">
            <span class="titulo-clases-hoy">Mis clases</span>
<!--            <span class="titulo-clases-hoy mr-12">Hoy</span>-->
          </div>
          <!-- Fin Titulo Mis Clases | Hoy-->

          <!-- Slider Mis clases-->
          <Miclases />
          <!-- Fin slider Mis clases -->

        </v-col>
        <!-- Fin Columna Mis Clases -->

        <!-- Columna Docentes-->
        <v-col cols="12" md="3" sm="6" class="order-sm-2 order-md-3 pr-0 pt-0 pb-0 col-docentes">
          <div class="d-flex justify-space-between pb-0 pl-4 ml-4">
            <span class="titulo-clases-hoy">Docentes</span>
<!--            <span class="titulo-clases-hoy">Docentes que refuerzan</span>-->
<!--            <span class="titulo-clases-hoy mr-12">Matematica</span>-->
          </div>
          <!-- Slider Docentes -->
          <Docentes />
          <!-- Fin Slider Docentes -->
        </v-col>
        <!--Fin Columna Docentes -->

        <!-- Columna Promociones -->
        <v-col cols="12" md="3" sm="6" class="order-sm-1 order-md-1 pt-0 col-docentes">
          <div class="pl-4 ml-4 mb-4">
            <span class="titulo-clases-hoy">Promociones</span>
          </div>
          <div class="ml-8 rounded-lg div-promociones">
            <v-row class="w-100">
              <v-col cols="6">
                <img src="@/assets/img/img/promocion.svg" alt="">
              </v-col>
              <v-col cols="6" class="pl-6 pt-8">
                <p class="mb-1 pr-1 titulo-promocion color-empresa">Toma tu primera clase</p>
                <center>
                  <v-btn
                    class="color-empresa text-transform rounded-pill w-100 white--text background-clases"
                    dark
                    small
                  >
                    Gratis
                  </v-btn>
                </center>
              </v-col>
            </v-row>
          </div>
        </v-col>
        <!-- Fin Columna Promociones -->
      </v-row>
    </div>
    <!-- Fin Cuerpo -->

    <!-- Reservar Clase -->
    <div class="d-flex align-center mr- mb-2 z-index-1 div-flotante d-none-x">
      <div class="rounded-pill nombre-user white--text mr-2 py-2 px-2  background-cladses" style="background:#3F3A64">
        Reservar Clase
      </div>
      <div class="rounded-circle d-flex h-100 justify-center align-center background-classes div-calendar" style="background:#3F3A64">
        <img height="35" width="35" src="@/assets/img/icon/calendar-white.svg" alt="Icon | Refuerza +">
      </div>
    </div>
    <!-- Fin Reservar Clase -->

    <!--Separador-->
    <div class="separador"></div>
    <!--Fin Separador -->

    <!-- Pie -->
    <v-footer :padless="true" fixed class="box-shadow pie">
      <v-card
        flat
        tile
        width="100%"
        class="white lighten-1 text-center"
      >
        <v-card-text>
          <v-btn class="mx-4" icon>
            <img size="24px" src="@/assets/img/icon/home.svg" alt="home | Refuerza +">
          </v-btn>
          <v-btn class="mx-4" to="perfil" icon>
            <img size="24px" src="@/assets/img/icon/user.svg" alt="user | Refuerza +">
          </v-btn>
          <v-btn class="mx-4" icon>
            <img size="24px" src="@/assets/img/icon/calendar.svg" alt="calendar | Refuerza +">
          </v-btn>
          <v-btn class="mx-4" icon>
            <img size="24px" src="@/assets/img/icon/stats.svg" alt="stats | Refuerza +">
          </v-btn>
        </v-card-text>
      </v-card>
    </v-footer>
    <!-- Fin Pie -->
  </div>
</template>
<script>
import Cabecera from '@/components/Cabecera.vue'
import Miclases from '@/components/Mi-Clases.vue'
import Docentes from '@/components/Docentes.vue'

import IconoMenu from '@/assets/img/icon/menu.svg'

export default {
  name: 'Inicio',
  data () {
    return {
      IconoMenu
    }
  },
  components: {
    Cabecera,
    Miclases,
    Docentes
  }

}
</script>

<style scoped src="@/assets/css/Estilos-Inicio.css"></style>
