<template>
  <div>
    <!-- Cabecera --->
    <v-app-bar
      color="white"
    >
      <!-- Icono de Menú -->
      <v-btn elevation="0" to="mensajes" x-small width="43" height="43" class="rounded-circle" color="transparent">
        <v-icon
          dark
          left
          class="my-2 mx-2 color-empresa"
        >
          mdi-arrow-left
        </v-icon>
      </v-btn>
      <!-- Fin Icono de Menú -->
      <v-avatar class="ml-3 avatar-inbox">
        <img src="@/assets/img/avatar.svg" alt="">
      </v-avatar>
      <span class="ml-3 color-empresa titulo-inbox color-empresa">Prof. Angela</span>
      <v-spacer></v-spacer>
      <!-- Icono de Menú -->
      <v-btn elevation="0" x-small width="43" height="43" class="rounded-circle" color="transparent">
        <v-icon
          dark
          left
          class="my-2 mx-2 color-empresa"
          size="25"
        >
          mdi-magnify
        </v-icon>
      </v-btn>
      <!-- Fin Icono de Menú -->
    </v-app-bar>
    <!-- Fin Cabecera -->

    <!-- Pie -->
    <v-footer :padless="true" fixed class="pie">
      <v-card
        flat
        tile
        width="100%"
        elevation="10"
        class="white lighten-1 text-center"
      >
        <v-card-text class="d-flex pt-5 pb-0">
          <v-btn class="mx-4 mr-0 pt-2" icon>
            <img size="24px" src="@/assets/img/icon/camera.svg" alt="home | Refuerza +">
          </v-btn>
          <v-btn class="mx-4 pt-2" icon>
            <img size="24px" src="@/assets/img/icon/clip.svg" alt="calendar | Refuerza +">
          </v-btn>
          <v-text-field
            elevation="0"
            class="rounded-pill"
            placeholder="Escriba aqui"
            dense
            outlined
          ></v-text-field>
        </v-card-text>
      </v-card>
    </v-footer>
    <!-- Fin Pie -->
  </div>
</template>

<style>
  .avatar-inbox{
    width: 40px!important;
    height: 40px!important;
  }
  .titulo-inbox{
    font-weight: 600;
    font-size: calc(15px + 1px);
    line-height: 22px;
  }
</style>
