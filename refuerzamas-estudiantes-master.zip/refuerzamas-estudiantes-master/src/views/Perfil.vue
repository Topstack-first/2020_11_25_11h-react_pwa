<template>
  <div class="perfil">
    <!-- Cabecera --->
    <v-app-bar
      color="white"
    >
      <!-- Icono de Menú -->
      <v-btn elevation="0" to="/" x-small width="43" height="43" class="rounded-circle" color="transparent">
        <v-icon
          dark
          left
          class="my-2 mx-2 color-empresa"
        >
          mdi-arrow-left
        </v-icon>
      </v-btn>
      <!-- Fin Icono de Menú -->

      <span class="ml-5 letras">Mi perfil</span>
    </v-app-bar>
    <!-- Fin Cabecera -->

    <!-- Icon -->
    <div>
      <img class="mt-5" src="@/assets/img/login/element-1.svg" alt="Element 1 | Refuerza +">
    </div>
    <!-- Icon -->

    <!-- Avatar User -->
    <center>
      <v-avatar class="mt-n7 mb-10" style="width:90px;height:90px;" @click="openFotoInput">
        <img :src="userEdited.avatar || 'https://cdn.vuetifyjs.com/images/john.jpg'" alt="John">
      </v-avatar>
    </center>
    <!-- Fin Avatar User -->

    <!-- Cuerpo -->
    <div style="">
      <v-row class="w-100 letras">

        <!-- Espaciador -->
        <v-spacer></v-spacer>
        <!-- Fin Espaciador -->

        <!-- Columna Izquierdo -->
        <v-col cols="2" sm="1" class="d-flex justify-end">
          <div class="mt-10 mr-n16 pr-n16">
            <img class="mt-4 mr-n16 pr-n16" src="@/assets/img/login/element-5.svg" alt="Element 5 | Refuerza +">
            <img class="mt-16 bottom mr-n16 pr-n16" src="@/assets/img/login/element-6.svg" alt="Element 6 | Refuerza +">
          </div>
        </v-col>
        <!-- Fin Columna Izquierdo -->

        <!-- Columna Medio -->
        <v-col cols="8" sm="6" style="z-index:1">
          <div class="white w-100 h-100">
            <v-form @submit.prevent="doUpdateUser" ref="form">
              <v-row>
                <!--Logo Refuerza +-->

                <div class="w-100 d-flex justify-end mt-n15 mr-n16 pr-n16 mb-n12">
                  <img class="mr-n16" width="100" src="@/assets/img/login/element-9.svg" alt="Element 9 | Refuerza +">
                </div>
                <div class="w-100 d-flex justify-center mt-1 mb-8">
                  <img class="logo" src="@/assets/img/logo.svg" alt="Logo | Refuerza +">
                </div>
                <!-- Fin Logo Refuerza + -->

                <!--Columna Nombres -->
                <v-col cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Nombres</span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    :disabled="disabledFields.first_name"
                    v-model="userEdited.first_name"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Nombres -->

                <!-- Columna Apellidos -->
                <v-col cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Apellidos</span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    :disabled="disabledFields.last_name"
                    v-model="userEdited.last_name"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Apellidos-->

                <!-- Columna Nivel -->
                <v-col v-if="userEdited.tipo_usuario === 'ESTUDIANTE'" cols="12" md="12" sm="12" class="py-0 my-0">
                  <span class="pl-5">Descripción</span>
                  <v-textarea
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    v-model="userEdited.perfil_estudiante.breve_cv"
                  ></v-textarea>
                </v-col>
                <!-- Fin Columna Nivel -->

                <!-- Columna Institución -->
                <v-col v-if="userEdited.tipo_usuario === 'ESTUDIANTE'" cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Institución</span>
                  <v-select
                    :items="instituciones"
                    item-text="nombre"
                    item-value="id"
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    v-model="userEdited.perfil_estudiante.institucion_id"
                  ></v-select>
                </v-col>
                <!-- Fin Columna Institución -->

                <!-- Columna Nivel -->
                <v-col v-if="userEdited.tipo_usuario === 'ESTUDIANTE'" cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Nivel</span>
                  <v-select
                    :items="niveles"
                    item-value="id"
                    item-text="nombre"
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    v-model="userEdited.nivel_id"
                    :disabled="disabledFields.nivel"
                    @change="doFetchGradosByNivel"
                  ></v-select>
                </v-col>
                <!-- Fin Columna Nivel -->

                <!-- Columna Grados -->
                <v-col v-if="userEdited.tipo_usuario === 'ESTUDIANTE'" cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Grado</span>
                  <v-select
                    :items="grados"
                    item-value="id"
                    item-text="nombre"
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    :disabled="disabledFields.grado"
                    v-model="userEdited.perfil_estudiante.grado_id"
                  ></v-select>
                </v-col>
                <!-- Fin Columna Grados -->

                <!-- Columna +51 -->
                <v-col cols="4" md="2" sm="4" class="py-0 my-0 mr-0 text-center">
                  <span class="pl-5">Celular</span>
                  <div class="w-100 pt-2 mt-2 rounded-pill" style="height:40%;border:1px solid #9e9e9e">
                    +51
                  </div>

                </v-col>
                <!-- Fin Columna +51 -->

                <!-- Columna Celular -->
                <v-col cols="8" md="4" sm="8" class="py-0 pl-0 pr-0 ml-n3 my-0">
                  <span class="pl-5"></span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    v-model="userEdited.celular"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Celular -->

                <!-- Columna Correo -->
                <v-col cols="12" md="12" sm="12" style="margin-left:10px" class="py-0 my-0 order-sm-2">
                  <span class="pl-5">Correo</span>
                  <v-text-field
                    class="w-100 pr-3 pt-2"
                    :rules="[rules.email]"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    disabled
                    v-model="userEdited.email"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Correo -->

                <!--Columna Género -->
                <v-col cols="12" md="6" sm="12" class="py-0 my-0 order-sm-1">
                  <span class="pl-5 order-sm-1">Género</span>
                  <v-select
                    :items="generos"
                    item-text="nombre"
                    item-value="id"
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    :disabled="disabledFields.genero"
                    v-model="userEdited.genero_id"
                  ></v-select>
                </v-col>
                <!-- Fin Columna Género -->

                <!-- Columna Tutor -->
                <v-col v-if="userEdited.tipo_usuario === 'ESTUDIANTE'" cols="12" md="12" class="py-0 my-0 order-sm-3">
                  <span class="pl-5">Datos del tutor</span><br>
                  <span class="pl-5">Nombres y Apellidos</span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    disabled
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Tutor -->

                <!-- Columna Btn Guardar -->
                <v-col cols="12" class="order-sm-4">
                  <v-btn
                    class="text-transform w-100 rounded-pill white--text background-clases"
                    large
                    depressed
                    medium
                    :loading="loading"
                    type="submit"
                  >Guardar
                  </v-btn>
                </v-col>
                <!-- Fin Columna Btn Guardar -->
              </v-row>
            </v-form>
          </div>
        </v-col>
        <!-- Fin Columna Medio -->

        <!-- Columna Derecho -->
        <v-col cols="2" sm="1" class="w-100">
          <div class="mt-16 pt-16 ml-n16 pl-n16" style="z-index:0">
            <img class="pt-16 ml-n12 " src="@/assets/img/login/element-7.svg" alt="Element 7 | Refuerza +"><br>
            <img class="mt-16 pt-16" src="@/assets/img/login/element-8.svg" alt="Element 8 | Refuerza +">
          </div>
        </v-col>
        <!-- Fin Columna Derecho -->

        <!-- Espaciador -->
        <v-spacer></v-spacer>
        <!-- Fin Espaciador -->

        <!-- Columna Inferior -->
        <v-col cols="12" sm="12" class="mt-n16 pt-n16 ml-n16 d-flex">
          <v-spacer></v-spacer>
          <img class="mt-n8 element-3 d-none-y" width="100" src="@/assets/img/login/element-3.svg"
               alt="Element 3 | Refuerza +">
          <v-spacer></v-spacer>
          <v-spacer></v-spacer>
          <v-spacer></v-spacer>
        </v-col>
        <!-- Fin Columna Inferior-->
      </v-row>
    </div>
    <AlertaModal @accept="confirmar" v-model="showAlert" :titulo="alertTitle" :mensaje="alertMessage"/>
    <input
      @change="doUploadFoto"
      accept="image/*"
      ref="fotoInput"
      type="file"
      v-show="false"
    >
    <!-- Fin Cuerpo -->
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import { email } from '@/utils/rules'
import AlertaModal from '@/components/AlertaModal'

export default {
  components: {
    AlertaModal
  },
  data () {
    return {
      showAlert: false,
      alertTitle: '',
      alertMessage: '',
      loading: false,
      disabledFields: {
        first_name: true,
        last_name: true,
        nivel: true,
        grado: true,
        genero: true
      },
      userEdited: {
        first_name: '',
        last_name: '',
        username: '',
        nickname: '',
        tipo_usuario: '',
        avatar: null,
        fecha_nacimiento: '',
        celular: '',
        email: '',
        direccion: null,
        observaciones: '',
        genero_id: '',
        nivel_id: '',
        perfil_estudiante: {
          institucion_id: '',
          grado_id: '',
          breve_cv: ''
        }
      },
      email: '',
      rules: {
        email
      }
    }
  },
  computed: {
    ...mapState('perfil', ['user', 'instituciones', 'generos', 'niveles', 'grados'])
  },
  methods: {
    ...mapActions('perfil', ['fetchUser', 'fetchInstituciones', 'fetchGeneros', 'fetchNiveles', 'fetchGrados', 'updateUser', 'fetchGradosByNivel', 'updatePhoto']),
    confirmar () {
      this.showAlert = false
    },
    async doUpdateUser () {
      try {
        this.loading = true
        delete this.userEdited.avatar
        if (this.userEdited.tipo_usuario === 'TUTOR') {
          delete this.userEdited.perfil_tutor
        }
        await this.updateUser(this.userEdited)
        this.userEdited.avatar = this.user.avatar
        this.alertTitle = '¡Felicidades!'
        this.alertMessage = 'Sus datos de usuario han sido modificados.'
        this.showAlert = true
      } catch (e) {
        this.alertTitle = '¡Lo sentimos!'
        this.alertMessage = 'Ha ocurrido un error. Inténtelo de nuevo en unos minutos.'
        this.showAlert = true
      } finally {
        this.loading = false
      }
    },
    async doFetchGradosByNivel () {
      await this.fetchGradosByNivel(this.userEdited.nivel_id)
    },
    calcularCamposDeshabilitados () {
      this.disabledFields.first_name = !!this.userEdited.first_name
      this.disabledFields.last_name = !!this.userEdited.last_name
      if (this.userEdited.tipo_usuario === 'ESTUDIANTE') {
        this.disabledFields.nivel = !!this.userEdited.perfil_estudiante.grado_id
        this.disabledFields.grado = !!this.userEdited.perfil_estudiante.grado_id
      }
      this.disabledFields.genero = !!this.userEdited.genero_id
    },
    openFotoInput () {
      this.$refs.fotoInput.click()
    },
    async doUploadFoto () {
      try {
        const foto = this.$refs.fotoInput.files[0]
        const payload = new FormData()
        payload.append('avatar', foto)
        await this.updatePhoto(payload)
        this.userEdited = this.user
        this.alertTitle = '¡Felicidades!'
        this.alertMessage = 'Su foto de perfil ha sido modificada.'
        this.showAlert = true
      } catch (e) {
        this.alertTitle = '¡Lo sentimos!'
        this.alertMessage = 'Ha ocurrido un error. Inténtelo de nuevo en unos minutos.'
        this.showAlert = true
      } finally {
        this.loading = false
      }
    }
  },
  async mounted () {
    await this.fetchUser()
    this.userEdited = this.user
    if (this.userEdited.tipo_usuario === 'ESTUDIANTE') {
      if (this.userEdited.perfil_estudiante.grado_id) {
        this.userEdited.nivel_id = this.user.perfil_estudiante.grado.nivel.id
        await this.doFetchGradosByNivel()
      }
    }
    this.calcularCamposDeshabilitados()
    await this.fetchInstituciones()
    await this.fetchGeneros()
    await this.fetchNiveles()
  }
}
</script>

<style src="@/assets/css/Estilos-Perfil.css"></style>
