<template>
  <div>
    <!-- Cabecera --->
    <v-app-bar
      color="white"
    >
      <!-- Icono de Menú -->
      <v-btn :to="{name: 'Inicio'}" elevation="0" x-small width="43" height="43" class="rounded-circle"
             color="transparent">
        <v-icon
          dark
          left
          class="my-2 mx-2 color-empresa"
        >
          mdi-arrow-left
        </v-icon>
      </v-btn>
      <!-- Fin Icono de Menú -->

      <span class="ml-5 color-empresa titulo-conversaciones">Mis conversaciones</span>
      <v-spacer></v-spacer>

      <!-- Persona de Chat que esta seleccionado -->

      <template v-if="currentChat">
        <p class="mt-4 mr-2 color-empresa d-none-me-2 font-weight-600">Prof. {{ currentChat.user1.display_name }}</p>
        <v-avatar class="d-none-me-2 avatar-seleccionado">
          <img :src="currentChat.user1.avatar || userDefaultAvatar" alt="">
        </v-avatar>
      </template>
      <!-- Fin Persona de Chat que esta seleccionado -->

      <!-- Icono de Lupa -->
      <v-btn
        dark
        icon
        class="color-empresa d-none-me"
      >
        <v-icon>mdi-magnify</v-icon>
      </v-btn>
      <!-- Fin Icono de Lupa -->
    </v-app-bar>
    <!-- Fin Cabecera -->

    <!-- Cuerpo -->
    <v-row class="mr-0  mt-0 pt-0 pr-0">
      <!-- Columna Lista de Mensajes -->
      <v-col cols="12" sm="12" md="4" class="w-100 mt-0 mb-0 pb-0 pr-0 pt-0 pr-40  mr-0">
        <!-- Lista de Mensajes Para Movil -->
        <v-list class="pt-1 d-none-me lista-mensaje-movil">
          <v-list-item-group class="pt-0 mt-0" v-model="model">
            <v-list-item
              v-for="chat in chats"
              :key="chat.id"
              style="border-bottom:1px solid #CBCBCB;background:white"
              @click="selectChatMovil(chat.id)"
              class="scroll mt-0 pt-0"
            >
              <v-list-item-icon class="mr-2">
                <v-avatar><img :src="chat.user1.avatar || userDefaultAvatar" alt=""></v-avatar>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="pb-2 nombre-mensaje color-empresa d-flex">Prof.{{
                    chat.user1.display_name
                  }}
                  <p v-if="user.tipo_usuario === 'TUTOR' && user.id!=chat.user2.id" class="px-1"
                     style="color: #E88E8E;">
                    ({{ chat.user2.display_name.split(' ')[0] }})
                  </p>
                </v-list-item-title>
                <v-list-item-subtitle class="color-empresa">
                  {{ chat.ultimo_mensaje ? chat.ultimo_mensaje.texto || 'Archivo adjunto' : 'Saluda al profesor' }}
                </v-list-item-subtitle>
              </v-list-item-content>
              <v-list-item-content class="content-lista-hora">
                <v-list-item-title class="d-flex justify-end mr-4 pb-2 color-empresa">
                  <span v-if="chat.mensajes_no_revisados_estudiante > 0"
                        class="rounded-circle text-center background-clases pt-1"
                        style="width:25px;height:25px"> {{ chat.mensajes_no_revisados_estudiante }}  </span>
                </v-list-item-title>
                <v-list-item-subtitle class="d-flex justify-end hora-mensaje color-empresa">
                  <span class="mt-5" v-if="chat.mensajes_no_revisados_estudiante == 0">
                    {{ mostrarFechaUltimoMensaje(chat.ultimo_mensaje) }}
                  </span>
                  <span v-if="chat.mensajes_no_revisados_estudiante > 0">
                    {{ mostrarFechaUltimoMensaje(chat.ultimo_mensaje) }}
                  </span>
                </v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
        <!-- Fin Lista de Mensajes para Movil -->

        <!-- Lista de Mensajes para PC -->
        <v-list class="pt-1 d-none-me-2 lista-mensaje-movil">
          <v-list-item-group class="pt-0 mt-0" v-model="model">
            <v-list-item
              v-for="chat in chats"
              :key="chat.id"
              style="border-bottom:1px solid #CBCBCB;background:white"
              class="scroll mt-0 pt-0"
              @click="chatSelectedId = chat.id"
            >
              <v-list-item-icon>
                <v-avatar><img :src="chat.user1.avatar || userDefaultAvatar" alt=""></v-avatar>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="pb-2 nombre-mensaje color-empresa d-flex">Prof. {{
                    chat.user1.display_name
                  }}
                  <p v-if="user.tipo_usuario === 'TUTOR' && user.id!=chat.user2.id" class="px-1 pb-0 mb-0"
                     style="color: #E88E8E;">
                    ({{ chat.user2.display_name.split(' ')[0] }})</p>
                </v-list-item-title>
                <v-list-item-subtitle class="color-empresa">
                  {{ chat.ultimo_mensaje ? chat.ultimo_mensaje.texto || 'Archivo adjunto' : 'Saluda al profesor' }}
                </v-list-item-subtitle>
              </v-list-item-content>
              <v-list-item-content class="content-lista-hora-pc">
                <v-list-item-title class="d-flex justify-end mr-4 pb-2 color-empresa">
                  <span v-if="chat.mensajes_no_revisados_estudiante > 0"
                        class="rounded-circle text-center background-clases pt-1"
                        style="width:25px;height:25px"> {{ chat.mensajes_no_revisados_estudiante }} </span>
                </v-list-item-title>
                <v-list-item-subtitle class="d-flex justify-end hora-mensaje color-empresa">
                  {{ mostrarFechaUltimoMensaje(chat.ultimo_mensaje) }}
                </v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
        <!-- Fin Lista de Mensajes para PC -->
      </v-col>
      <!-- Fin Columna Lista de Mensajes -->

      <!-- Columna de INBOX para PC -->
      <v-col cols="0" sm="" class="ml-0 mr-0 pr-0 ml-n10 mr-0 mb-0 pb-0 d-none-me-3">
        <v-container class="color-empresa container-inbox d-flex flex-column-reverse">
          <div ref="scroll-to"></div>
          <div v-for="mensaje in mensajes" :key="mensaje.id" class="d-flex"
               :class="mensaje.user === user.id || mensaje.tutor === user.id?'justify-end':''">
            <div v-if="mensaje.user !== user.id && mensaje.tutor !== user.id" class="my-1 pa-2 mensaje-emisor">
              <p v-if="mensaje.texto" class="mensaje-texto mb-0">{{ mensaje.texto }}</p>
              <a v-else-if="isFoto(mensaje.archivo)" :href="mensaje.archivo" target="_blank">
                <v-img :src="mensaje.archivo" alt=""></v-img>
              </a>
              <a v-else target="_blank" :href="mensaje.archivo"
                 class="color-empresa text-decoration-none mensaje-texto">
                <v-icon class="color-empresa" large>mdi-download</v-icon>
                {{ mostrarTituloArchivo(mensaje.archivo) }}
              </a>
              <p class="px-1 py-0 text-end my-0 mensaje-hora">{{ mensaje.fecha | moment('hh:mm a') }}</p>
            </div>
            <div v-else-if="mensaje.user === user.id || mensaje.tutor === user.id"
                 class="my-1 pa-2 background-clases mensaje-emisor">
              <p v-if="mensaje.texto" class="mensaje-texto mb-0">{{ mensaje.texto }}</p>
              <a v-else-if="isFoto(mensaje.archivo)" :href="mensaje.archivo" target="_blank">
                <v-img :src="mensaje.archivo" alt=""></v-img>
              </a>
              <a v-else target="_blank" :href="mensaje.archivo" class="color-empresa text-decoration-none mensaje-texto"
              >
                <v-icon class="color-empresa" large>mdi-download</v-icon>
                {{ mostrarTituloArchivo(mensaje.archivo) }}
              </a>
              <p class="px-1 py-0 text-end my-0 mensaje-hora">{{ mensaje.fecha | moment('hh:mm a') }}</p>
            </div>
          </div>
        </v-container>

        <v-footer :padless="true" class="pie ml-n3 pl-0 mb-0 pb-0">
          <v-card
            tile
            width="100%"
            elevation="0"
            class="text-center"
            style="border-top:1px solid #CBCBCB"
          >
            <v-form @submit.prevent="sendMensaje" ref="form">

              <v-card-text class="d-flex pt-5" v-if="currentChat">
                <v-btn class="mx-4 mr-0 pt-2" icon :disabled="user.id !== currentChat.user2.id">
                  <img size="24px" src="@/assets/img/icon/camera.svg" alt="home | Refuerza +" @click="openFotoInput">
                </v-btn>
                <v-btn class="mx-4 pt-2" icon :disabled="user.id !== currentChat.user2.id">
                  <img size="24px" src="@/assets/img/icon/clip.svg" alt="calendar | Refuerza +" @click="openFileInput">
                </v-btn>
                <v-text-field
                  elevation="0"
                  class="rounded-pill"
                  placeholder="Escriba aqui"
                  dense
                  outlined
                  :disabled="user.id !== currentChat.user2.id"
                  v-model="mensaje"
                ></v-text-field>
                <v-btn class="mx-4 ml-4 mr-2 mt-1" style="background:#c4c4d9" icon @click="sendMensaje">
                  <v-icon
                    large
                    class="white--text"
                  >
                    mdi-chevron-right
                  </v-icon>
                </v-btn>
              </v-card-text>
            </v-form>
          </v-card>
        </v-footer>
      </v-col>
      <!-- Fin Columna de INBOX para PC-->
    </v-row>

    <!-- Dialog INBOX para MOVIL-->
    <v-dialog
      v-model="dialog"
      fullscreen
      hide-overlay
      transition="dialog-bottom-transition"
      scrollable
    >
      <!-- Contenedor -->
      <v-card tile class="white" style="height:50px">
        <v-toolbar
          flat
          dark
          class="white"
          elevation="2"
          style="height:0px"
        >
          <v-btn
            icon
            dark
            class="color-empresa"
            @click="dialog = false"
          >
            <v-icon>mdi-arrow-left</v-icon>
          </v-btn>
          <v-toolbar-title v-if="currentChat" class="color-empresa dialog-persona-inbox">Prof.
            {{ currentChat.user1.display_name }}
          </v-toolbar-title>
          <v-spacer></v-spacer>
          <v-btn
            dark
            icon
            class="color-empresa"
          >
            <v-icon>mdi-magnify</v-icon>
          </v-btn>
        </v-toolbar>

        <v-card-text style="height:70%">
          <v-container id="padreChat" class="ma-0 pa-0 color-empresa d-flex flex-column-reverse">
            <div ref="scroll-to-movil">
              <div class="my-1 pa-2 pb-0">
                <p class=""></p>
              </div>
            </div>
            <div v-for="mensaje in mensajes" :key="mensaje.id" class="d-flex"
                 :class="mensaje.user === user.id || mensaje.tutor === user.id?'justify-end':''">
              <!-- Emisor -->
              <div v-if="mensaje.user !== user.id && mensaje.tutor !== user.id" class="pa-2 my-1 mensaje-emisor-movil">
                <p v-if="mensaje.texto" class="mb-0 mensaje-texto-movil" style="">{{ mensaje.texto }}</p>
                <a v-else-if="isFoto(mensaje.archivo)" :href="mensaje.archivo" target="_blank">
                  <v-img :src="mensaje.archivo" alt=""></v-img>
                </a>
                <a v-else target="_blank" :href="mensaje.archivo"
                   class="color-empresa text-decoration-none mensaje-texto-movil">
                  <v-icon class="color-empresa" large>mdi-download</v-icon>
                  {{ mostrarTituloArchivo(mensaje.archivo) }}
                </a>
                <p class="text-end my-0 mt-0 mensaje-hora-movil">{{ mensaje.fecha | moment('hh:mm a') }}</p>
              </div>
              <!-- Fin Emisor -->

              <!-- Receptor -->
              <div v-else-if="mensaje.user === user.id || mensaje.tutor === user.id"
                   class="my-1 pa-2 pb-0 background-clases mensaje-emisor-movil">
                <p v-if="mensaje.texto" class="mb-0 mensaje-texto-movil">{{ mensaje.texto }}</p>
                <a v-else-if="isFoto(mensaje.archivo)" :href="mensaje.archivo" target="_blank">
                  <v-img :src="mensaje.archivo" alt=""></v-img>
                </a>
                <a v-else target="_blank" :href="mensaje.archivo"
                   class="color-empresa text-decoration-none mensaje-texto-movil"
                >
                  <v-icon class="color-empresa" large>mdi-download</v-icon>
                  {{ mostrarTituloArchivo(mensaje.archivo) }}
                </a>
                <p class="text-end my-0 mt-0 mensaje-hora-movil">{{ mensaje.fecha | moment('hh:mm a') }}</p>
              </div>
            </div>
          </v-container>

          <!-- PIE -->
          <v-footer :padless="true" fixed class="pie">
            <v-card
              flat
              tile
              width="100%"
              elevation="10"
              class="white lighten-1 text-center"
            >
              <v-card-text class="d-flex pt-5 pb-0  pl-0 pr-0 mr-0">
                <v-btn class="mx-4 mr-0 pt-2" icon>
                  <img size="24px" src="@/assets/img/icon/camera.svg" alt="Camera | Refuerza +" @click="openFotoInput">
                </v-btn>
                <v-btn class="mx-4 ml-2 mr-1 pt-2" icon>
                  <img size="24px" src="@/assets/img/icon/clip.svg" alt="Clip | Refuerza +" @click="openFileInput">
                </v-btn>
                <v-text-field
                  elevation="0"
                  class="rounded-pill"
                  placeholder="Escriba aqui"
                  dense
                  outlined
                  v-model="mensaje"
                  @keyup.enter="sendMensaje"
                ></v-text-field>
                <v-btn
                  class="mx-4 ml-1 mr-2 mt-1"
                  style="background:#c4c4d9"
                  icon
                  @click="sendMensaje"
                >
                  <v-icon
                    large
                    class="white--text"
                  >
                    mdi-chevron-right
                  </v-icon>
                </v-btn>
              </v-card-text>
            </v-card>
          </v-footer>
          <!-- Fin PIE -->
        </v-card-text>
        <div style="flex: 1 1 auto;"></div>
      </v-card>
      <!-- Fin Contenedor -->
    </v-dialog>
    <input
      @change="doUploadFoto"
      accept="image/*"
      ref="fotoInput"
      type="file"
      v-show="false"
    >
    <input
      @change="doUploadFile"
      accept=".docx, .pdf, .doc, .csv, .xlsx, xls, ppt, pptx"
      ref="fileInput"
      type="file"
      v-show="false"
    >
    <!-- Fin Dialog INBOX para MOVIL-->
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import moment from 'moment'
import axios from '@/plugins/axios'
import pusher from '@/plugins/pusher'
import userDefaultAvatar from '@/assets/img/user_default.jpg'

export default {
  data: () => ({
    userDefaultAvatar,
    model: null,
    dialog: false,
    mensajes: [],
    chatSelectedId: null,
    mensaje: ''
  }),
  computed: {
    ...mapState('chat', ['chats']),
    ...mapState('perfil', ['user']),
    currentChat () {
      const index = this.chats.findIndex(chat => chat.id === this.chatSelectedId)
      return index === -1 ? null : this.chats[index]
    }
  },
  watch: {
    async chatSelectedId () {
      await this.fetchMensajesByChat()
      await this.marcarComoVisto(this.chatSelectedId)
      this.$refs['scroll-to-movil'].scrollIntoView({ block: 'end' })
    }
  },
  methods: {
    ...mapActions('chat', ['fetchChats', 'marcarComoVisto']),
    ...mapActions('perfil', ['fetchUser']),
    mostrarFechaUltimoMensaje (ultimoMensaje) {
      if (ultimoMensaje) {
        return moment(ultimoMensaje.fecha).format('HH:mm a')
      }
      return ''
    },
    async fetchMensajesByChat () {
      const mensajesResponse = await axios.get(`/api/chats/${this.chatSelectedId}/mensajes/`)
      this.mensajes = mensajesResponse.data
    },
    selectChatMovil (chatId) {
      this.dialog = true
      this.chatSelectedId = chatId
      // console.log(this.$refs)
      // const modal = document.getElementById('dialog-movil')
      // modal.scrollTop = modal.scrollHeight
    },
    async sendMensaje () {
      if (this.mensaje) {
        const data = {
          chat: this.chatSelectedId,
          texto: this.mensaje
        }
        await axios.post('/api/mensajes/', data)
        this.mensaje = ''
        this.$refs['scroll-to'].scrollIntoView({ block: 'end' })
      }
    },
    async sendFile (payload) {
      payload.append('chat', this.chatSelectedId)
      await axios.post('/api/mensajes/', payload)
      this.$refs['scroll-to'].scrollIntoView({ block: 'end' })
    },
    openFileInput () {
      this.$refs.fileInput.click()
    },
    openFotoInput () {
      this.$refs.fotoInput.click()
    },
    async doUploadFoto () {
      try {
        const foto = this.$refs.fotoInput.files[0]
        const payload = new FormData()
        payload.append('archivo', foto)
        await this.sendFile(payload)
      } catch (e) {
        console.log(e)
      }
    },
    async doUploadFile () {
      try {
        const file = this.$refs.fileInput.files[0]
        const payload = new FormData()
        payload.append('archivo', file)
        await this.sendFile(payload)
      } catch (e) {
        console.log(e)
      }
    },
    mostrarTituloArchivo (archivo) {
      if (archivo) {
        return archivo.split('/').pop()
      }
      return ''
    },
    isFoto (archivo) {
      if (archivo) {
        return archivo.endsWith('.jpg') || archivo.endsWith('.png') || archivo.endsWith('.gif') || archivo.endsWith('.webp') || archivo.endsWith('.jpeg')
      }
      return false
    }
  },
  async mounted () {
    await this.fetchChats()
    await this.fetchUser()
    if (this.chats.length > 0) {
      this.chatSelectedId = this.chats[0].id
    }

    this.chats.forEach(chat => {
      const channel = pusher.subscribe(`chat-${chat.id}`)
      channel.bind('mensaje', async (mensaje) => {
        if (mensaje.chat === this.chatSelectedId) {
          this.mensajes.unshift(mensaje)
          await this.marcarComoVisto(this.chatSelectedId)
        } else {
          await this.fetchChats()
        }
      })
    })
  }
}
</script>

<style scoped src="@/assets/css/Estilos-Mensajes.css"></style>
