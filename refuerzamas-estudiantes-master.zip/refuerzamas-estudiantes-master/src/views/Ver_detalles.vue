<template>
  <div>
    <!-- Cabecera -->
    <Cabecera Icono="https://www.chioscoffebreak.com/img/left-flecha.svg" to="/"/>
    <!-- Fin Cabecera -->

    <!-- Cuerpo-->
    <div class="color-empresa">
      <v-row class="w-100">

        <v-col cols="0" sm="3" class="col-promocion">
          <div class="pl-4 ml-4 mb-4 d-none-do">
            <span class="titulo-promociones-detalles">Promociones</span>
          </div>
          <div class="d-none-do ml-8 rounded-lg div-promociones" style="width:86%;border:1px solid #e0e0e0;">
            <v-row class="w-100">
              <v-col cols="6">
                <img src="@/assets/img/img/promocion.svg" alt="">
              </v-col>
              <v-col cols="6" class="pl-6 pt-8">
                <p class="mb-1 titulo-promocion color-empresa" style="font-size:12px;font-weight:600">Toma tu primera
                  clase</p>
                <center>
                  <v-btn
                    class="color-empresa text-transform rounded-pill w-100 white--text background-clases"
                    dark
                    small
                  >
                    Gratis
                  </v-btn>
                </center>
              </v-col>
            </v-row>
          </div>
        </v-col>
        <!------------------------------------------------------------------------------------------>
        <v-col cols="12" sm="12" md="6" class="col-detalle" v-if="clase">
          <!-- Columna I -->
          <v-row>
            <v-col cols="12" class="pb-0">
              <v-row class="w-100">
                <!--Separador -->
                <v-spacer></v-spacer>
                <!--Fin Separador -->

                <!-- Columna Derecha -->
                <v-col cols="3" md="2" sm="2" class="">
                  <center>
                    <!-- Avatar Docente-->
                    <v-avatar class="avatar-docente">
                      <img :src="clase.docente.avatar || userDefaultAvatar" :alt="clase.docente.display_name">
                    </v-avatar>
                    <!-- Fin Avatar Docente-->

                    <!-- Valoración -->
                    <div>
                      <v-btn
                        elevation="0"
                        class="btn-valoracion rounded-pill white mt-2 w-90 h-90 mt-3 py-2 color-empresa"
                        style="border:1px solid #E5E5E5!important;"
                        small
                      >
                        {{ clase.docente.perfil_docente.estrellas }}
                        <v-icon x-small color="amber">mdi-star</v-icon>
                      </v-btn>
                    </div>
                    <!-- Fin Valoración -->
                  </center>
                </v-col>
                <!-- Fin Columna Derecha -->

                <!-- Columna Izquierdo -->
                <v-col cols="9" sm="10" class="pb-0 pr-0">
                  <!--Nombre Docente -->
                  <p class="nombre-docente color-empresa mb-3">Prof. {{ clase.docente.display_name }}</p>
                  <!-- Fin Nombre Docente -->

                  <!-- Descripción Docente -->
                  <p class="texto-docente color-empresa">{{ clase.docente.perfil_docente.breve_cv }}</p>
                  <!-- Fin Descripción Docente -->
                  <template v-if="user">
                    <p v-if="user.tipo_usuario === 'TUTOR'" class="d-flex align-center"
                       style="color: #311FB5;font-weight: 500;font-size: 0.75rem;">
                      <v-img class="flex-grow-0 mr-1" style="border-radius: 50%;" height="15" width="15"
                             :src="clase.user.avatar || userDefaultAvatar"></v-img>
                      {{ clase.user.display_name.split(' ')[0] }}
                    </p>
                  </template>
                </v-col>
                <!-- Fin Columna Izquierdo -->
                <v-spacer></v-spacer>
              </v-row>
            </v-col>
            <!-- Fin Columna I -->

            <!-- Columna II -->
            <v-col cols="12" class="py-0">
              <v-row class="w-100">
                <v-spacer></v-spacer>
                <!-- Titulo Datos Clases -->
                <v-col cols="12" sm="12" class="mb-0 pb-0">
                  <p class="titulo-datos-clases mb-0">Datos de Clase</p>
                </v-col>
                <!-- Titulo Datos Clases -->
              </v-row>
              <v-row>
                <v-spacer></v-spacer>
                <!-- Columna Dia -->
                <v-col cols="4" sm="4">
                  <div class="borde d-flex justify-center align-center w-100 rounded-lg h-100">
                    <img class="px-1 icon-datos" width="30%" src="@/assets/img/icon/calendar-heart.svg"
                         alt="Icon | Refuerza +">
                    <div class="text-center">
                      <p class="texto-datos-clases pt-5 pb-0 mb-0">
                        {{ clase.hora_inicio | moment('dddd') | capitalize }}</p>
                      <p class="texto-datos-clases px-2">{{ clase.hora_inicio | moment('D') }}</p>
                    </div>
                  </div>
                </v-col>
                <!-- Fin Columna Dia -->

                <!-- Columna Horario -->
                <v-col cols="4" sm="4">
                  <div class="borde d-flex w-100 rounded-lg justify-center align-center h-100">
                    <img class="px-1 icon-datos" width="30%" src="@/assets/img/icon/time-five.svg"
                         alt="Icon | Refuerza +">
                    <div class="text-center">
                      <p class="texto-datos-clases pt-5 pb-0 mb-0">Horario</p>
                      <p class="texto-datos-clases-horario px-2">{{ clase.hora_inicio | moment('hh:mma') }} a
                        {{ clase.hora_fin | moment('hh:mma') }}</p>
                    </div>
                  </div>
                </v-col>
                <!-- Fin Columna Horario -->

                <!-- Columna Nombre Clases -->
                <v-col cols="4" sm="4">
                  <div class="borde h-100 rounded-lg d-flex align-center justify-center h-100">
                    <p class="texto-datos-clases text-center mb-0">{{ clase.curso.materia.nombre }}</p>
                  </div>
                </v-col>
                <!-- Fin Columna Nombre Clases-->
                <v-spacer></v-spacer>
              </v-row>
            </v-col>

            <v-col cols="12">
              <v-row class="w-100">
                <v-spacer></v-spacer>
                <!-- Titulo Indicaciones Clases -->
                <v-col cols="12" sm="12" class="mt-0 pt-0">
                  <p class="titulo-datos-clases mb-0">Indicaciones de la clase</p>
                </v-col>
                <!-- Titulo Indicaciones Clases -->
              </v-row>
              <v-row>
                <v-spacer></v-spacer>
                <!-- Titulo Indicaciones Clases -->
                <v-col cols="12" sm="12" class="mt-0 pt-0">
                  <p class="texto-indicaciones mb-0">
                    1. Ingresar al curso cinco minutos antes del inicio de su clase. <br>
                    2. Es importante que cuiden su vestimenta, ruidos y entorno. <br>
                    3. Tengan especial cuidado si usan cámaras de video y micrófonos, es mejor tenerlos apagados a menos
                    que el docente les pida una intervención.
                  </p>
                </v-col>
                <!-- Titulo Indicaciones Clases -->
                <v-spacer></v-spacer>
              </v-row>
            </v-col>

            <v-col cols="12">
              <v-row class="w-100">
                <v-spacer></v-spacer>
                <!-- Titulo Indicaciones Clases -->
                <v-col cols="12" sm="12" class="mt-0 pt-0 d-flex align-center">
                  <img class="call-img" width="13%" src="@/assets/img/img/service2.svg" alt="Service | Refuerza +">
                  <v-btn
                    class="ml-5 background-clases rounded-pill white--text text-transform"
                    elevation="0"
                    style="border:1px solid #E5E5E5!important;font-weight:200"
                    href="https://wa.link/fb1ewz"
                    target="_blank"
                  >
                    ¿Necesitas ayuda?
                  </v-btn>
                </v-col>
                <!-- Titulo Indicaciones Clases -->
              </v-row>
              <v-row class="w-100">
                <v-spacer></v-spacer>
                <!-- Titulo Indicaciones Clases -->
                <v-col cols="12" sm="6" class="pl-0 mt-0 pt-0">
                  <v-btn
                    class="ml-5 white rounded-pill color-empresa text-transform w-100 btn-indicaciones-video"
                    elevation="0"
                    large
                    style="border:1px solid #E5E5E5!important;"
                    :href="clase.enlace_videollamada"
                    target="_blank"
                  >
                    Ir a la videollamada
                  </v-btn>
                </v-col>
                <v-col cols="12" sm="6" class="pl-0 mt-0 pt-0">
                  <v-btn
                    class="ml-5 background-clases rounded-pill white--text text-transform w-100 btn-indicaciones-video"
                    elevation="0"
                    large
                    style="border:1px solid #E5E5E5!important;"
                    :to="{name: 'Mensajes'}"
                  >
                    Chatear con docente
                  </v-btn>
                </v-col>
                <!-- Titulo Indicaciones Clases -->
                <v-spacer></v-spacer>
              </v-row>
            </v-col>
          </v-row>
        </v-col>

        <!-------------------------------------------------------------------------------------------->
        <v-col cols="0" sm="3" class="pr-0 pb-0 w-100 col-promocion">
          <div class="pl-4 ml-4 d-none-do">
            <span class="titulo-promociones-detalles">Docentes</span>
          </div>
          <div class="d-none-do">
            <Docentes/>
          </div>
        </v-col>

      </v-row>

    </div>
    <!-- Fin Cuerpo -->
  </div>
</template>

<script>
import Cabecera from '@/components/Cabecera.vue'
import Docentes from '@/components/Docentes.vue'
import axios from 'axios'
import IconoFlecha from '@/assets/img/icon/left-flecha.svg'
import userDefaultAvatar from '@/assets/img/user_default.jpg'
import { mapActions, mapState } from 'vuex'

export default {
  data () {
    return {
      IconoFlecha,
      clase: null,
      userDefaultAvatar
    }
  },
  components: {
    Cabecera,
    Docentes
  },
  computed: {
    ...mapState('perfil', ['user'])
  },
  methods: {
    ...mapActions('perfil', ['fetchUser'])
  },
  async mounted () {
    this.fetchUser()
    const claseId = this.$route.params.id
    try {
      const claseResponse = await axios.get(`api/clases/${claseId}`)
      this.clase = claseResponse.data
    } catch (e) {
      console.log(e)
      await this.$router.push({ name: 'Inicio' })
      // TODO añadir ventana de clase no encontrada si es erro 404
    }
  }
}
</script>

<style src="@/assets/css/Estilos-VerDetalles.css"></style>
