import axios from 'axios'
import store from '../store'

if (process.env.NODE_ENV === 'production') {
  axios.defaults.baseURL = 'https://api.refuerzamas.com'
} else {
  axios.defaults.baseURL = 'http://localhost:8000'
  // axios.defaults.baseURL = 'https://api.refuerzamas.com'
}

axios.interceptors.request.use(async function (config) {
  if (store.state.token) {
    const token = store.state.token
    const authorization = `Token ${token}`
    config.headers.Authorization = authorization
    return config
  } else {
    config.headers.Authorization = null
    return config
  }
})

export default axios
