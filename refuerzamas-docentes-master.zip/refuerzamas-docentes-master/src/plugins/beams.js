// import { Client } from '@pusher/push-notifications-web/dist/push-notifications-esm'
//
// const beamsClient = new Client({
//   instanceId: 'dfe1654a-b2a2-4c00-834e-6bb13ea2db2f'
// })
// export default beamsClient
