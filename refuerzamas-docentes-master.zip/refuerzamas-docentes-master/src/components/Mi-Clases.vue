<template>
  <div>
    <!-- Contenedor -->
    <div
      class="ma-4 rounded-lg card-clases color-empresa"
      flat
    >
      <v-row class="row-clases rounded-lg horizontal">
        <!-- Primera Columna -->
        <v-col cols="4" class="py-0 px-0">
          <div class="fondo-clases h-100 rounded-l-lg">
            <div class="d-flex justify-end w-100">
              <!-- Avatar Docentes -->
              <v-avatar class="mt-14 mr-n6">
                <img :src="clase.user.avatar || userDefaultAvatar" alt="">
              </v-avatar>
              <!-- Avatar Docentes -->
            </div>
            <div class="d-flex justify-end">
              <!-- Valoración Docentes -->
              <v-btn
                class="mr-n5 mt-3 color-empresa text-transform rounded-pill btn-valoracion"
                color="white"
                dark
                x-small
              >
                {{ clase.user.perfil_estudiante.estrellas }} <img src="@/assets/img/icon/start.svg"
                                                                  alt="Icon | Refuerza +">
              </v-btn>
              <!-- Valoración Docentes -->
            </div>
            <center>
              <!-- Btn Activo -->
              <v-btn
                class="ma-2 color-empresa text-transform rounded-pill btn-activo"
                color="white"
                elevation="0"
                dark
                x-small
              >
                <img src="@/assets/img/icon/check.svg" alt="Icon | Refuerza +">
                {{ clase.estado }}
              </v-btn>
              <!-- Btn Activo -->
            </center>
          </div>
        </v-col>
        <!-- Fin Primera Columna -->

        <!-- Segunda Columna -->
        <v-col cols="8" class="pl-8 pl2-clases">
          <div class="d-flex justify-space-between">
            <div class="pt-2" style="width:100%">
              <!-- Nombre de la Clase -->
              <p class="titulo-curso-clases">{{ clase.curso.materia.nombre }}</p>
              <!-- Fin Nombre de la Clase -->
            </div>
            <div class="ml-2">
              <v-menu
                left
                offset-y
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-btn
                    color="white"
                    text
                    v-bind="attrs"
                    v-on="on"
                    class="pr-0"
                  >
                    <img class="mr-n5" src="@/assets/img/icon/puntitos.svg" alt="Icon | Refuerza +">
                  </v-btn>
                </template>

                <v-list class="mb-0 pb-0">
                  <v-list-item
                    style="border-bottom:1px solid #E5E5E5"
                  >
                    <v-list-item-title class="color-empresa"
                                       style="font-weight: 600;font-size: calc(12px + 2px);line-height: 17px;">Reportar
                    </v-list-item-title>
                  </v-list-item>
                  <v-list-item
                    style="border-bottom:1px solid #E5E5E5"
                  >
                    <v-list-item-title class="color-empresa"
                                       style="font-weight: 600;font-size: calc(12px + 2px);line-height: 17px;">Cancelar
                    </v-list-item-title>
                  </v-list-item>
                </v-list>
              </v-menu>
              <!-- Icono -->

              <!-- Fin Icono -->
            </div>
          </div>
          <!-- Nombre Docente-->
          <p class="profe-clases w-100 mb-1">{{ clase.user.short_display_name || clase.user.display_name }}</p>
          <!-- Fin Nombre Docente-->

          <!-- Horario -->
          <p class="horario-clases">{{ calcularDia(clase.hora_inicio) }}, de {{ clase.hora_inicio | moment('hh:mma') }}
            a {{ clase.hora_fin | moment('hh:mma') }}</p>
          <!-- Fin Horario -->
          <center class="pr-5">
            <!-- Btn Detalles -->
            <v-btn
              :to="{name: 'Clase', params: {id: clase.id}}"
              elevation="0"
              class="ma-2 ml-0 w-100 mt-0 background-clases white--text text-transform rounded-pill btn-detalles"
              dark
            >
              Ver detalles
            </v-btn>
            <!-- fin btn detalles -->
          </center>
        </v-col>
        <!--Fin segunda Columna -->
      </v-row>
    </div>
    <!-- Fin Contenedor -->
  </div>
</template>

<script>
import userDefaultAvatar from '@/assets/img/user_default.jpg'
import moment from 'moment'
export default {
  props: {
    clase: Object
  },
  data () {
    return {
      model: null,
      userDefaultAvatar,
      items: [
        { title: 'Reportar' },
        { title: 'Cancelar' }
      ]
    }
  },
  methods: {
    calcularDia (fecha) {
      return moment(fecha).calendar({
        sameDay: '[Hoy]',
        nextDay: '[Mañana]',
        nextWeek: 'dddd',
        lastDay: '[Ayer]',
        lastWeek: 'dddd [pasado]',
        sameElse: '[El] DD [de] MMM [del] YYYY'
      })
    }
  }
}
</script>

<style scoped>
.row-clases {
  height: 100%;
  border: 1px solid #e0e0e0;
  border-left: none;
}

.fondo-clases {
  background-image: url(https://www.chioscoffebreak.com/img/clases.svg);
  background-size: cover;
  background-position: center;
  height: 100%;
  width: 100%;
}

.btn-valoracion, .btn-activo {
  font-weight: 600;
  font-size: 10px;
  letter-spacing: normal;
}

.pl2-clases {
  padding-left: 40px !important;
}

.titulo-curso-clases {
  font-weight: 600;
  font-size: calc(15px + 1px);
  line-height: 17px;
  white-space: break-spaces;
}

.profe-clases {
  font-weight: 500;
  font-size: calc(15px + 1px);
  line-height: 17px;
  white-space: break-spaces;
  word-break: break-all;
}

.horario-clases {
  font-weight: 300;
  font-size: calc(12px + 1px);
  line-height: 15px;
}

.btn-detalles {
  font-weight: 300;
  font-size: calc(14px + 1px);
  letter-spacing: normal;
}
</style>
