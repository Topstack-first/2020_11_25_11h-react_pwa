<template>
  <div>
    <div class="ml-4 mb-4">
      <span class="color-empresa" style="font-weight:600">Estudiantes</span>
    </div>
    <div class="ml-4 rounded-lg div-promociones" style="border:1px solid #E5E5E5">
      <v-row class="card-profesores rounded-lg ml-1">
        <!--Primera Columna -->
        <v-col cols="4" class="text-center d-flex flex-column justify-center align-center">
          <!-- Img Avatar Docentes -->
          <v-avatar class="avatar-docentes">
            <img src="@/assets/img/avatar.svg" alt="">
          </v-avatar>
          <!-- Fin Avatar Docentes -->
          <!--Valoracion Docentes -->
          <v-btn
            class="color-empresa text-transform rounded-pill mt-2"
            color="white"
            dark
            elevation="2"
            x-small
          >
            4.5<img src="@/assets/img/icon/start.svg" alt="Icon | Refuerza +">
          </v-btn>
          <!-- Fin Valoracion Docentes -->
        </v-col>
        <!-- Fin Primera Columna -->

        <!-- Segunda Columna -->
        <v-col cols="8" class="text-center d-flex flex-column justify-space-between align-center">
          <!-- Nombre Docentes-->
          <p class="my-0 color-empresa" style="font-size:12px;font-weight:600">Prof. Ronaldo Ramirez Orlando</p>
          <!-- Fin Nombre Docentes-->
          <!-- btn ver perfil-->
          <v-btn
            class="my-0 color-empresa text-transform rounded-pill white--text background-clases"
            dark
            x-small
            style="letter-space:normal"
          >
            Ver perfil
          </v-btn>
          <!-- Fin btn perfil -->
        </v-col>
        <!-- Fin Segunda Columna -->
      </v-row>
    </div>
  </div>
</template>
