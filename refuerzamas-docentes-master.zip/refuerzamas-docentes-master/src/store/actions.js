import axios from 'axios'

export default {

  login: async ({ commit }, payload) => {
    const tokenResponse = await axios.post('api/auth-token/docente', payload)
    const token = tokenResponse.data.token
    localStorage.setItem('token', token)
    commit('SET_TOKEN', token)
  },

  fetchClases: async ({ commit }) => {
    const clasesResponse = await axios.get('api/clases/')
    const clases = clasesResponse.data
    commit('SET_CLASES', clases)
  },
  fetchDocentes: async ({ commit }) => {
    const docentesResponse = await axios.get('api/docentes/')
    const docentes = docentesResponse.data
    commit('SET_DOCENTES', docentes)
  },
  logout: ({ commit }) => {
    localStorage.removeItem('token')
    commit('SET_TOKEN', null)
  }

}
