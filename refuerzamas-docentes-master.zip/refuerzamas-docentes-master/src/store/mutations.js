import { set } from '@/utils/vuex'

export default {
  SET_TOKEN: set('token'),
  SET_CLASES: set('clases'),
  SET_DOCENTES: set('docentes')
}
