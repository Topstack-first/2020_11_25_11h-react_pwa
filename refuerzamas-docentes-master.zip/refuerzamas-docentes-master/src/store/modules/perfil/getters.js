// https://vuex.vuejs.org/en/getters.html
// import foto from '../../../assets/img/foto-prueba.svg'

export default {
  // getFoto: (state) => {
  //   if(state.user.foto != '' && state.user.foto){
  //     return state.user.foto
  //   }else if(state.user.avatar_social != '' && state.user.avatar_social){
  //     return state.user.avatar_social
  //   }else{
  //     return foto
  //   }
  // },
}
