// https://vuex.vuejs.org/en/state.html
// TODO  obtener token try - catch, JSON parse error
export default {
  token: localStorage.getItem('token') || null,
  clases: [],
  docentes: []
}
