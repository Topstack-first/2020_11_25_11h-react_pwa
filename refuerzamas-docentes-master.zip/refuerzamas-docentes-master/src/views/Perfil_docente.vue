<template>
  <div>
    <!-- Cabecera --->
    <v-app-bar
      color="white"
    >
      <!-- Icono de Menú -->
      <v-btn elevation="0" to="/" x-small width="43" height="43" class="rounded-circle" color="transparent">
        <v-icon
          dark
          left
          class="my-2 mx-2 color-empresa"
        >
          mdi-arrow-left
        </v-icon>
      </v-btn>
      <!-- Fin Icono de Menú -->

      <span class="ml-5 perfil-docente color-empresa">Perfil del docente</span>
    </v-app-bar>
    <!-- Fin Cabecera -->

    <!--Cuerpo -->
    <v-row class="mr-0 pr-0">
      <v-col cols="0" sm="3" class="mt-3 d-none-detalle">
          <div class="pl-4 ml-4 mb-4">
            <span style="font-weight:600">Promociones</span>
          </div>
          <div class="ml-8 rounded-lg div-promociones" style="border:1px solid #E5E5E5">
            <v-row class="w-100">
              <v-col cols="6">
                <img width="" src="@/assets/img/img/promocion.svg" alt="">
              </v-col>
              <v-col cols="6" class="pl-6 pt-8">
                <p class="mb-1 color-empresa" style="font-size:12px;font-weight:500">Toma tu primera clase</p>
                <center>
                  <v-btn
                    class="color-empresa text-transform rounded-pill w-100 white--text background-clases"
                    dark
                    small
                  >
                    Gratis
                  </v-btn>
                </center>
              </v-col>
            </v-row>
          </div>
        </v-col>

      <v-spacer></v-spacer>
      <v-col cols="12" sm="12" md="6" class="pt-0 pr-0">
        <div class="color-empresa">
          <!-- Fondo -->
          <img class="w-100 d-none-p" src="@/assets/img/img/fondo-docente.svg" alt="Fondo | Refuerza +">
          <!-- Fin Fondo -->

          <center>
            <!-- Avatar Docente -->
            <v-avatar class="avatar-docente">
              <img src="@/assets/img/avatar.svg" alt="Avatar docente | Refuerza +">
            </v-avatar>
            <!-- Fin Avatar Docente -->

            <!-- Nombre Docente -->
            <p class="mt-5 mb-2 pb-0 nombre-docente">Angela Martinez</p>
            <!-- Fin Nombre Docente -->

            <!-- Descripcion Docente -->
            <v-row class="w-100">
              <v-spacer></v-spacer>
              <v-col cols="11" sm="11" md="12" class="text-justify descripcion-docente">
                “El objeto de la educación es formar seres aptos para gobernarse a sí mismos, y no para se gobernados por los demás”
              </v-col>
              <v-spacer></v-spacer>
            </v-row>
            <!-- Fin Descripcion Docente -->
          </center>
        </div>

        <v-row class="w-100">
          <v-spacer></v-spacer>
          <!-- Titulo Datos Clases -->
          <v-col cols="11" sm="11" md="12" class="mb-0 pb-0">
            <p class="titulo-cursos-docente color-empresa mb-0">Mis cursos que dicto</p>
          </v-col>
          <!-- Titulo Datos Clases -->
        </v-row>

        <v-row class="p-docente mr-0 pr-0 w-100">
          <v-spacer></v-spacer>
          <v-col cols="12" class="pr-0" sm="12" md="12">
            <!-- Slider Mis clases-->
            <v-sheet
              class="mx-auto vertical"
            >
              <v-slide-group
                v-model="model"
                class="pa-4 pt-0 pr-0 w-100"
                active-class=""
                show-arrows
              >
                <v-slide-item
                  v-for="n in 10"
                  :key="n"
                  v-slot:default="{ active, toggle }"
                >

                  <!-- Contenedor -->
                  <v-card
                    :color="active ? undefined : 'white'"
                    class="ma-4 rounded-lg card-cursos borde"
                    flat
                    @click="toggle"
                  >
                    <div class="pb-2 row-clases d-flex rounded-lg justify-center align-center">
                      <img class="px-1 pt-2" width="35%" src="@/assets/img/icon/icon-quimica.svg" alt="Icon | Refuerza +">
                      <div class="text-center">
                        <p class="texto-cursos color-empresa pt-5 pb-0 mb-0">Química Escolar</p>
                      </div>
                    </div>
                  </v-card>
                  <!-- Fin Contenedor -->

                </v-slide-item>
              </v-slide-group>
            </v-sheet>
            <!-- Fin slider Mis clases -->
          </v-col>
          <v-spacer></v-spacer>
        </v-row>

        <v-row class="w-100">
          <v-spacer></v-spacer>
          <!-- Titulo Datos Clases -->
          <v-col cols="11" sm="11" md="12" class="mb-0 pb-0">
            <p class="titulo-cursos-docente color-empresa mb-0">Mis horarios libres</p>
          </v-col>
          <!-- Titulo Datos Clases -->
        </v-row>

        <v-row class="p-docente mr-0 pr-0 w-100">
          <v-spacer></v-spacer>
          <v-col cols="12" class="pr-0" sm="12" md="12">
            <!-- Slider Mis clases-->
            <v-sheet
              class="mx-auto vertical"
            >
              <v-slide-group
                v-model="model2"
                class="pa-4 pt-0 pr-0 w-100"
                active-class=""
                show-arrows
              >
                <v-slide-item
                  v-for="n in 10"
                  :key="n"
                  v-slot:default="{ active, toggle }"
                >

                  <!-- Contenedor -->
                  <v-card
                    :color="active ? undefined : 'white'"
                    class="ma-4 rounded-lg card-horario"
                    flat
                    @click="toggle"
                  >
                    <div class="row-clases d-flex rounded-lg justify-center">
                      <p class="texto-cursos color-empresa pt-3 pb-0 mb-0">Lunes</p>
                    </div>
                  </v-card>
                  <!-- Fin Contenedor -->

                </v-slide-item>
              </v-slide-group>
            </v-sheet>
            <!-- Fin slider Mis clases -->
          </v-col>
          <v-spacer></v-spacer>
        </v-row>

        <v-row class="w-100">
          <v-spacer></v-spacer>
        </v-row>

        <v-row class="w-100">
          <v-spacer></v-spacer>
          <!-- Titulo Indicaciones Clases -->
          <v-col cols="11" sm="11" md="11" class="pl-0 mt-0 pt-0 mb-5 w-100">
            <v-btn
              class="ml-5 background-clases rounded-pill white--text text-transform w-100"
              elevation="0"
              large
              @click.stop="dialog = true"
              style="border:1px solid #E5E5E5!important;font-weight:500;font-size:calc(17px + 1px);letter-spacing:normal"
            >
              Ver mi disponibilidad
            </v-btn>

            <v-dialog
              v-model="dialog"
              max-width="400"
            >
              <v-card>
                <v-card-title class="color-empresa" style="font-weight: 600;font-size: calc(15px + 1px);line-height: 22px;">
                  <v-container>
                    Lunes 23 de Octubre
                  </v-container>
                </v-card-title>

                <v-card-text>
                  <v-container>
                    <v-btn class="w-100 mb-5 white text-transform rounded-pill">
                      9:00am - 11:00am
                    </v-btn>
                    <v-btn class="w-100 mb-5 white text-transform rounded-pill">
                      9:00am - 11:00am
                    </v-btn>
                    <v-btn class="w-100 mb-5 white text-transform rounded-pill">
                      9:00am - 11:00am
                    </v-btn>
                    <v-btn class="w-100 white text-transform rounded-pill">
                      9:00am - 11:00am
                    </v-btn>
                  </v-container>
                </v-card-text>
              </v-card>
            </v-dialog>
          </v-col>
          <!-- Titulo Indicaciones Clases -->
          <v-spacer></v-spacer>
        </v-row>
      </v-col>
      <v-spacer></v-spacer>
       <v-col cols="0" sm="3" class="mt-3 mr-0 pr-0 d-none-detalle">
          <div class="mb-4">
            <span style="font-weight:600">Estudiantes</span>
          </div>
          <MiClases :clase="clase"/>
        </v-col>
    </v-row>
  </div>
</template>
<script>
import MiClases from '@/components/Mi-Clases.vue'
export default {
  data () {
    return {
      model: null,
      model2: null,
      dialog: false
    }
  },
  components: {
    MiClases
  }
}
</script>
<style scoped src="@/assets/css/Estilos-Perfil-Docente.css"></style>
