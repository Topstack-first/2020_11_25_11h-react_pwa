<template>
  <div class="perfil">
    <!-- Cabecera --->
    <v-app-bar
      color="white"
    >
      <!-- Icono de Menú -->
      <v-btn elevation="0" to="/" x-small width="43" height="43" class="rounded-circle" color="transparent">
        <v-icon
          dark
          left
          class="my-2 mx-2 color-empresa"
        >
          mdi-arrow-left
        </v-icon>
      </v-btn>
      <!-- Fin Icono de Menú -->

      <span class="ml-5 letras">Mi perfil</span>
    </v-app-bar>
    <!-- Fin Cabecera -->

    <!-- Icon -->
    <div>
      <img class="mt-5" src="@/assets/img/login/element-1.svg" alt="Element 1 | Refuerza +">
    </div>
    <!-- Icon -->

    <!-- Avatar User -->
    <center>
      <v-avatar class="mt-n7 mb-10" style="width:90px;height:90px;" @click="openFotoInput">
        <img :src="userEdited.avatar || 'https://cdn.vuetifyjs.com/images/john.jpg'" alt="John">
      </v-avatar>
    </center>
    <!-- Fin Avatar User -->

    <!-- Cuerpo -->
    <div style="">
      <v-row class="w-100 letras">

        <!-- Espaciador -->
        <v-spacer></v-spacer>
        <!-- Fin Espaciador -->

        <!-- Columna Izquierdo -->
        <v-col cols="2" sm="1" class="d-flex justify-end">
          <div class="mt-10 mr-n16 pr-n16">
            <img class="mt-4 mr-n16 pr-n16" src="@/assets/img/login/element-5.svg" alt="Element 5 | Refuerza +">
            <img class="mt-16 bottom mr-n16 pr-n16" src="@/assets/img/login/element-6.svg" alt="Element 6 | Refuerza +">
          </div>
        </v-col>
        <!-- Fin Columna Izquierdo -->

        <!-- Columna Medio -->
        <v-col cols="8" sm="6" style="z-index:1">
          <div class="white w-100 h-100">
            <v-form @submit.prevent="doUpdateUser" ref="form">
              <v-row>
                <!--Logo Refuerza +-->

                <div class="w-100 d-flex justify-end mt-n15 mr-n16 pr-n16 mb-n12">
                  <img class="mr-n16" width="100" src="@/assets/img/login/element-9.svg" alt="Element 9 | Refuerza +">
                </div>
                <div class="w-100 d-flex justify-center mt-1 mb-8">
                  <img class="logo" src="@/assets/img/logo.svg" alt="Logo | Refuerza +">
                </div>
                <!-- Fin Logo Refuerza + -->

                <!--Columna Nombres -->
                <v-col cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Nombres</span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    :disabled="disabledFields.first_name"
                    v-model="userEdited.first_name"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Nombres -->

                <!-- Columna Apellidos -->
                <v-col cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Apellidos</span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    :disabled="disabledFields.last_name"
                    v-model="userEdited.last_name"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Apellidos-->

                <!-- Columna Frase -->
                <v-col cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Frase inspiradora</span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    v-model="userEdited.perfil_docente.filosofia"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Frase -->

                <!-- Columna Frase -->
                <v-col cols="12" md="6" sm="12" class="py-0 my-0">
                  <span class="pl-5">Cursos</span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Frase -->

                <!--                &lt;!&ndash; Columna Nivel &ndash;&gt;-->
                <!--                <v-col cols="12" md="6" sm="12" class="py-0 my-0">-->
                <!--                  <span class="pl-5">Nivel</span>-->
                <!--                  <v-text-field-->
                <!--                    class="w-100 px-2 pt-2"-->
                <!--                    placeholder=""-->
                <!--                    dense-->
                <!--                    outlined-->
                <!--                    rounded-->
                <!--                  ></v-text-field>-->
                <!--                </v-col>-->
                <!--                &lt;!&ndash; Fin Columna Nivel &ndash;&gt;-->

                <!--                &lt;!&ndash; Columna Horario &ndash;&gt;-->
                <!--                <v-col cols="12" md="6" sm="12" class="py-0 my-0">-->
                <!--                  <span class="pl-5">Horarios disponibles</span>-->
                <!--                  <v-text-field-->
                <!--                    class="w-100 px-2 pt-2"-->
                <!--                    placeholder=""-->
                <!--                    dense-->
                <!--                    outlined-->
                <!--                    rounded-->
                <!--                  ></v-text-field>-->
                <!--                </v-col>-->
                <!--                &lt;!&ndash; Fin Columna Horario &ndash;&gt;-->

                <!-- Columna +51 -->
                <v-col cols="4" md="2" sm="4" class="py-0 my-0 mr-0 text-center">
                  <span class="pl-5">Celular</span>
                  <div class="w-100 pt-2 mt-2 rounded-pill" style="height:40%;border:1px solid #9e9e9e">
                    +51
                  </div>
                </v-col>
                <!-- Fin Columna +51 -->

                <!-- Columna Celular -->
                <v-col cols="8" md="4" sm="8" class="py-0 pl-0 pr-0 ml-n3 my-0">
                  <span class="pl-5"></span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    v-model="userEdited.celular"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Celular -->

                <!-- Columna Correo -->
                <v-col cols="12" md="12" sm="12" style="margin-left:10px" class="py-0 my-0 order-sm-2">
                  <span class="pl-5">Correo</span>
                  <v-text-field
                    class="w-100 pr-3 pt-2"
                    :rules="[rules.email]"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    disabled
                    v-model="userEdited.email"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Correo -->

                <!--Columna Género -->
                <v-col cols="12" md="6" sm="12" class="py-0 my-0 order-sm-1">
                  <span class="pl-5 order-sm-1">Género</span>
                  <v-select
                    :items="generos"
                    item-text="nombre"
                    item-value="id"
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    :disabled="disabledFields.genero"
                    v-model="userEdited.genero_id"
                  ></v-select>
                </v-col>
                <!-- Fin Columna Género -->

                <!-- Columna Calificacion -->
                <v-col cols="12" md="12" class="py-0 my-0 order-sm-3">
                  <span class="pl-5 order-sm-1">Calificación</span>
                  <v-text-field
                    class="w-100 px-2 pt-2"
                    placeholder=""
                    dense
                    outlined
                    rounded
                    disabled
                    v-model="userEdited.perfil_docente.estrellas"
                  ></v-text-field>
                </v-col>
                <!-- Fin Columna Calificacion -->

                <!-- Columna Btn Guardar -->
                <v-col cols="12" class="order-sm-4">
                  <v-btn
                    class="text-transform w-100 rounded-pill white--text background-clases"
                    large
                    depressed
                    medium
                    :loading="loading"
                    type="submit"
                  >Guardar
                  </v-btn>
                </v-col>
                <!-- Fin Columna Btn Guardar -->
              </v-row>
            </v-form>
          </div>
        </v-col>
        <!-- Fin Columna Medio -->

        <!-- Columna Derecho -->
        <v-col cols="2" sm="1" class="w-100">
          <div class="mt-16 pt-16 ml-n16 pl-n16" style="z-index:0">
            <img class="pt-16 ml-n12 " src="@/assets/img/login/element-7.svg" alt="Element 7 | Refuerza +"><br>
            <img class="mt-16 pt-16" src="@/assets/img/login/element-8.svg" alt="Element 8 | Refuerza +">
          </div>
        </v-col>
        <!-- Fin Columna Derecho -->

        <!-- Espaciador -->
        <v-spacer></v-spacer>
        <!-- Fin Espaciador -->

        <!-- Columna Inferior -->
        <v-col cols="12" sm="12" class="mt-n16 pt-n16 ml-n16 d-flex">
          <v-spacer></v-spacer>
          <img class="mt-n8 element-3 d-none-y" width="100" src="@/assets/img/login/element-3.svg"
               alt="Element 3 | Refuerza +">
          <v-spacer></v-spacer>
          <v-spacer></v-spacer>
          <v-spacer></v-spacer>
        </v-col>
        <!-- Fin Columna Inferior-->
      </v-row>
    </div>
    <AlertaModal @accept="confirmar" v-model="showAlert" :titulo="alertTitle" :mensaje="alertMessage"/>
    <input
      @change="doUploadFoto"
      accept="image/*"
      ref="fotoInput"
      type="file"
      v-show="false"
    >
    <!-- Fin Cuerpo -->
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import { email } from '@/utils/rules'
import AlertaModal from '@/components/AlertaModal'

export default {
  components: {
    AlertaModal
  },
  data () {
    return {
      showAlert: false,
      alertTitle: '',
      alertMessage: '',
      loading: false,
      disabledFields: {
        first_name: true,
        last_name: true,
        genero: true
      },
      userEdited: {
        first_name: '',
        last_name: '',
        username: '',
        nickname: '',
        tipo_usuario: '',
        avatar: null,
        fecha_nacimiento: '',
        celular: '',
        email: '',
        direccion: null,
        observaciones: '',
        genero_id: '',
        nivel_id: '',
        perfil_docente: {
          institucion_id: '',
          grado_id: ''
        }
      },
      rules: {
        email
      }
    }
  },
  computed: {
    ...mapState('perfil', ['user', 'generos'])
  },
  methods: {
    ...mapActions('perfil', ['fetchUser', 'fetchGeneros', 'updateUser', 'updatePhoto']),
    confirmar () {
      this.showAlert = false
    },
    async doUpdateUser () {
      try {
        this.loading = true
        delete this.userEdited.avatar
        await this.updateUser(this.userEdited)
        this.userEdited.avatar = this.user.avatar
        this.alertTitle = '¡Felicidades!'
        this.alertMessage = 'Sus datos de usuario han sido modificados.'
        this.showAlert = true
      } catch (e) {
        console.log(e)
        this.alertTitle = '¡Lo sentimos!'
        this.alertMessage = 'Ha ocurrido un error. Inténtelo de nuevo en unos minutos.'
        this.showAlert = true
      } finally {
        this.loading = false
      }
    },
    calcularCamposDeshabilitados () {
      this.disabledFields.first_name = !!this.userEdited.first_name
      this.disabledFields.last_name = !!this.userEdited.last_name
      this.disabledFields.genero = !!this.userEdited.genero_id
    },
    openFotoInput () {
      this.$refs.fotoInput.click()
    },
    async doUploadFoto () {
      try {
        const foto = this.$refs.fotoInput.files[0]
        const payload = new FormData()
        payload.append('avatar', foto)
        await this.updatePhoto(payload)
        this.userEdited = this.user
        this.alertTitle = '¡Felicidades!'
        this.alertMessage = 'Su foto de perfil ha sido modificada.'
        this.showAlert = true
      } catch (e) {
        this.alertTitle = '¡Lo sentimos!'
        this.alertMessage = 'Ha ocurrido un error. Inténtelo de nuevo en unos minutos.'
        this.showAlert = true
      } finally {
        this.loading = false
      }
    }
  },
  async mounted () {
    await this.fetchUser()
    this.userEdited = this.user
    this.calcularCamposDeshabilitados()
    await this.fetchGeneros()
  }
}
</script>

<style src="@/assets/css/Estilos-Perfil.css"></style>
