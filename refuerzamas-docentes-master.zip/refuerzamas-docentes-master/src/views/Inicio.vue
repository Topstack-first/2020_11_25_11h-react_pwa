<template>
  <div>
    <!-- Cabecera -->
    <Cabecera :Icono="IconMenu"/>
    <!-- Fin Cabecera -->

    <v-container>
      <v-row>
        <v-spacer></v-spacer>
        <v-col cols="0" sm="3" class="d-none-es">
          <div class="mr-4 mb-4">
            <span class="color-empresa" style="font-weight:600">Promociones</span>
          </div>
          <div class="mr-4 rounded-lg div-promociones" style="border:1px solid #E5E5E5">
            <v-row class="w-100">
              <v-col cols="6" class="d-flex align-center">
                <img width="100" src="@/assets/img/img/promocion.svg" alt="">
              </v-col>
              <v-col cols="6" class="pl-4 pt-5">
                <p class="mb-1 color-empresa" style="font-size:12px;font-weight:500">Toma tu primera clase</p>
                <center>
                  <v-btn
                    class="color-empresa text-transform rounded-pill w-100 white--text background-clases"
                    dark
                    small
                  >
                    Gratis
                  </v-btn>
                </center>
              </v-col>
            </v-row>
          </div>
        </v-col>

        <v-col cols="12" sm="5" >
          <!-- Contenedor -->
          <div v-for="clase in clases" :key="clase.id"><MiClases :clase="clase"/></div>
          <!-- Fin Contenedor -->
        </v-col>

        <v-col cols="0" sm="3" class="d-none-es">
          <Estudiantes />
        </v-col>
        <v-spacer></v-spacer>
      </v-row>
      <div style="width:1px;height:70px"></div>
      <!-- Pie -->
      <v-footer :padless="true" fixed class="box-shadow pie">
        <v-card
          flat
          tile
          width="100%"
          class="white lighten-1 text-center"
        >
          <v-card-text>
            <v-btn class="mx-4" icon>
              <img size="24px" src="@/assets/img/icon/home.svg" alt="home | Refuerza +">
            </v-btn>
            <v-btn class="mx-4" to="perfil" icon>
              <img size="24px" src="@/assets/img/icon/user.svg" alt="user | Refuerza +">
            </v-btn>
            <v-btn class="mx-4" icon>
              <img size="24px" src="@/assets/img/icon/calendar.svg" alt="calendar | Refuerza +">
            </v-btn>
            <v-btn class="mx-4" icon>
              <img size="24px" src="@/assets/img/icon/stats.svg" alt="stats | Refuerza +">
            </v-btn>
          </v-card-text>
        </v-card>
      </v-footer>
      <!-- Fin Pie -->

      <!-- Inicio modal    -->
      <v-dialog
        v-model="dialog"
        max-width="290"
        v-if="clase"
      >
        <v-card>
          <v-card-text class="color-empresa">
            <v-container>
              <center>
                <img src="@/assets/img/icon/modal.svg" alt="">
              </center>
            </v-container>
            <p class="color-empresa mb-1" style="font-weight:600">{{ clase.user.display_name }}</p>
            Requiero clases de ({{ clase.curso.materia.nombre }}) {{ calcularDia(clase.hora_inicio) }}, de
            {{ clase.hora_inicio | moment('hh:mma') }}
            a {{ clase.hora_fin | moment('hh:mma') }}
          </v-card-text>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              class="mb-2"
              color="background-clases white--text"
              style="background:#52D0A1;text-transform:none;color:white;letter-spacing:normal;font-weight: normal;width:40%;"
              text
              @click="aceptarClase"
            >
              Aceptar
            </v-btn>
            <v-btn
              class="mb-2"
              color="color-empresa"
              style="color:#3F3A64;border:1px solid #e0e0e0;text-transform:none;letter-spacing:normal; font-weight: normal;width:40%"
              text
              @click="rechazarClase"
            >
              Rechazar
            </v-btn>
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>
      <!-- Fin modal    -->
    </v-container>
    <AlertaModal @accept="confirmar" v-model="showAlert" :titulo="alertTitle" :mensaje="alertMessage"/>
  </div>
</template>

<script>
import Cabecera from '@/components/Cabecera.vue'
import MiClases from '@/components/Mi-Clases.vue'
import pusher from '@/plugins/pusher'
import Estudiantes from '@/components/Estudiantes.vue'

import IconMenu from '@/assets/img/icon/menu.svg'
import { mapActions, mapState } from 'vuex'
import userDefaultAvatar from '@/assets/img/user_default.jpg'
import moment from 'moment'
import axios from '@/plugins/axios'
import AlertaModal from '@/components/AlertaModal'

export default {
  data () {
    return {
      clase: null,
      IconMenu,
      userDefaultAvatar,
      showAlert: false,
      alertTitle: '',
      alertMessage: '',
      dialog: false
    }
  },
  components: {
    Cabecera,
    MiClases,
    AlertaModal,
    Estudiantes
  },
  computed: {
    ...mapState(['clases']),
    ...mapState('perfil', ['user'])
  },
  methods: {
    ...mapActions(['fetchClases']),
    ...mapActions('perfil', ['fetchUser']),
    calcularDia (fecha) {
      return moment(fecha).calendar({
        sameDay: '[Hoy]',
        nextDay: '[Mañana]',
        nextWeek: 'dddd',
        lastDay: '[Ayer]',
        lastWeek: 'dddd [pasado]',
        sameElse: '[el] DD [de] MMM [del] YYYY'
      })
    },
    async aceptarClase () {
      try {
        this.dialog = false
        await axios.post(`/api/reservas/${this.clase.id}/tomar/`)
        await this.fetchClases()
        this.alertTitle = '¡Felicidades!'
        this.alertMessage = 'Has tomado esta clase.'
        this.showAlert = true
      } catch (e) {
        this.alertTitle = '¡Lo sentimos!'
        this.alertMessage = 'La clase ya ha sido tomada.'
        this.showAlert = true
      }
    },
    rechazarClase () {
      this.dialog = false
      this.clase = null
    },
    confirmar () {
      this.showAlert = false
      this.clase = null
      this.fetchUltimaReserva()
    },
    async fetchUltimaReserva () {
      const reservaResponse = await axios.get('/api/reservas/ultimo/')
      if (reservaResponse.data.id) {
        this.clase = reservaResponse.data
        this.dialog = true
      } else {
        this.clase = null
        this.dialog = false
      }
    }
  },
  async mounted () {
    await this.fetchUser()
    await this.fetchClases()
    await this.fetchUltimaReserva()
    this.user.perfil_docente.cursos.forEach(curso => {
      const channel = pusher.subscribe(`clase-curso-${curso.id}`)
      channel.bind('clase_disponible', async (clase) => {
        if (!this.clase) {
          this.clase = clase
          this.dialog = true
        }
      })
      channel.bind('clase_reservada', async (clase) => {
        this.clase = null
        this.dialog = false
        await this.fetchUltimaReserva()
      })
    })
  }
}
</script>

<style scoped src="@/assets/css/Estilos-Inicio.css"></style>
