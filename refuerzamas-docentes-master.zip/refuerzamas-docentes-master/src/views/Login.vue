<template>
  <div class="login h-100 w-100">
    <br>
    <div>
      <img src="@/assets/img/login/element-1.svg" alt="element-1 | Refuerza +">
    </div>
    <div class="logo">
      <center>
        <img class="logo-img height-100" src="@/assets/img/logo.svg" alt="Logo | Refuerza +">
      </center>
    </div>
    <!-- Cuerpo -->
    <v-container>
      <center>
        <!-- Element img parte superior -->
        <div class="d-flex justify-space-between element-superior">
          <img class="ml-16 pl-10 mb-n10" src="@/assets/img/login/element-2.svg" alt="Element 2 | Refuerza +">
          <img class="ml-16 mb-n6" src="@/assets/img/login/element-3.svg" alt="Element 3 | Refuerza +">
        </div>
        <!--Fin Element img parte superior-->

        <!-- Login -->
        <v-form
          ref="form"
          class="rounded-lg div-login py-7 color-empresa"
          @submit.prevent="doLogin"
          v-model="isValid"
        >
          <!--Titulo Iniciar Sesión -->
          <h3 class="titulo-sesion">Iniciar Sesión</h3>
          <!-- Fin titulo iniciar Sesión -->

          <!-- Correo -->
          <div class="d-flex w-80">
            <h3 class="label pl-3 pb-3">Correo</h3>
          </div>
          <v-text-field
            class="w-80"
            v-model="email"
            :rules="[rules.required, rules.email]"
            placeholder="refuerzamas@gmail.com"
            outlined
            rounded
          ></v-text-field>
          <!-- Fin Correo -->

          <!-- Contraseña -->
          <div class="d-flex w-80">
            <h3 class="label pl-3 pb-3">Contraseña</h3>
          </div>
          <v-text-field
            class="w-80"
            v-model="password"
            :rules="[rules.required]"
            :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
            :type="show1 ? 'text' : 'password'"
            @click:append="show1 = !show1"
            outlined
            rounded
          ></v-text-field>
          <!-- Fin Contraseña -->

          <!-- btn Ingresar -->
          <v-btn
            class="btn-ingresar text-transform w-80 rounded-pill white--text background-clases"
            large
            depressed
            medium
            type="submit"
            :disabled="!isValid"
            :loading="loading"
          > Ingresar
          </v-btn>
          <!-- Fin btn Ingresar -->
        </v-form>
        <!-- Fin Login -->

        <!-- Element img inferior -->
        <div class="d-flex justify-space-between element-inferior">
          <img class="ml-1 mt-n10" src="@/assets/img/login/element-4.svg" alt="Element 4 | Refueza +">
          <img class="mt-n16 pt-n16" src="@/assets/img/login/element-3.svg" alt="Element 3 | Refueza +">
          <img class="mt-n16 pt-n16" src="@/assets/img/login/element-4.svg" alt="Element 4 | Refueza +">
        </div>
        <!-- Fin Element img inferior -->
      </center>
    </v-container>
    <!-- Fin cuerpo -->
  </div>
</template>

<script>
import { email, required } from '@/utils/rules'
import { mapActions } from 'vuex'

export default {
  data () {
    return {
      show1: false,
      loading: false,
      loginError: false,
      email: '',
      password: '',
      isValid: false,
      rules: {
        required,
        email
      }
    }
  },
  methods: {
    ...mapActions(['login']),
    async doLogin () {
      console.log(this.$refs)
      if (this.$refs.form.validate()) {
        this.loading = true
        try {
          const payload = {
            username: this.email,
            password: this.password
          }
          await this.login(payload)
          this.$router.push({ name: 'Inicio' })
        } catch (e) {
          this.loginError = true
          console.log(e)
        } finally {
          this.loading = false
        }
      }
    }
  }
}

</script>

<style src="@/assets/css/Estilos-Login.css"></style>
