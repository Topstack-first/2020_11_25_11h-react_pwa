module.exports = {
  transpileDependencies: [
    'vuetify'
  ],
  pwa: {
    name: 'Refuerzamas Docentes',
    themeColor: '#000000',
    appleMobileWebAppCapable: 'yes',
    appleMobileWebAppStatusBarStyle: 'black',
    // workboxPluginMode: 'InjectManifest',
    // workboxOptions: {
    //   swSrc: './src/service-worker.js'
    // },
    manifestOptions: {
      background_color: '#ffffff',
      orientation: 'portrait',
      start_url: 'index.html',
      display: 'standalone',
      icons: [
        {
          src: 'img/icons/icon-192.png',
          sizes: '192x192',
          type: 'image/png',
          purpose: 'maskable any'
        },
        {
          src: 'img/icons/icon-512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'maskable any'
        }
      ]
    },
    iconPaths: {
      favicon16: 'favicon.png',
      favicon32: 'favicon.png',
      appleTouchIcon: 'img/icons/icon-512.png'
    }
  }

}
